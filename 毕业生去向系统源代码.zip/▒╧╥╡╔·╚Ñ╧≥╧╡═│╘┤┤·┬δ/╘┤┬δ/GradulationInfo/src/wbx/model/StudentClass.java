package wbx.model;
//�༶��Ϣ
public class StudentClass {
	private int Cno;
	private String Cname;
	private String Tname;
	private String Info;
	public int getCno() {
		return Cno;
	}
	public void setCno(int cno) {
		Cno = cno;
	}
	public String getCname() {
		return Cname;
	}
	public void setCname(String cname) {
		Cname = cname;
	}
	public String getTname() {
		return Tname;
	}
	public void setTname(String tname) {
		Tname = tname;
	}
	public String getInfo() {
		return Info;
	}
	public void setInfo(String info) {
		Info = info;
	}
	@Override
	public String toString(){
		return this.Cname;
	}
	
}
