package wbx.model;
/**
 * 
 * @author llq
 *ѡ��ȥ���
 */
public class SelectedG_Destination {
	private int id;
	private int student_id;
	private int destination_id;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getStudent_id() {
		return student_id;
	}
	public void setStudent_id(int student_id) {
		this.student_id = student_id;
	}
	public int getDestination_id() {
		return destination_id;
	}
	public void setDestination_id(int destination_id) {
		this.destination_id = destination_id;
	}
	
}
