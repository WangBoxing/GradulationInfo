package wbx.model;

public class UNGradulation {
	private int Gsno;
	private String Gsname;
	private String Password;
	private int Cno;
	private String Sex;
	public int getGsno() {
		return Gsno;
	}
	public void setGsno(int gsno) {
		Gsno = gsno;
	}
	public String getGsname() {
		return Gsname;
	}
	public void setGsname(String gsname) {
		Gsname = gsname;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public int getCno() {
		return Cno;
	}
	public void setCno(int cno) {
		Cno = cno;
	}
	public String getSex() {
		return Sex;
	}
	public void setSex(String sex) {
		this.Sex = sex;
	}
}
