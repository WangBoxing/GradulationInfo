package wbx.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import wbx.model.Confirm;
import wbx.model.SelectedG_Destination;
import wbx.util.StringUtil;

public class ConfirmDao extends BaseDao {
	public boolean addConfirm(Confirm confirm){
		String sql = "insert into g_confirm values(null,?,?,?)";
		try {
			java.sql.PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setInt(1, confirm.getStudent_id());
			preparedStatement.setInt(2, confirm.getDestination_id());
			preparedStatement.setString(3, confirm.getConfirm_date());
			if(preparedStatement.executeUpdate() > 0)return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public boolean isConfirmd(Confirm confirm){
		String sql = "select * from g_confirm where student_id=? and destination_id = ? and confirm_date = ?";
		try {
			PreparedStatement prst = con.prepareStatement(sql);//��sql��䴫�����ݿ��������
			prst.setInt(1, confirm.getStudent_id());
			prst.setInt(2, confirm.getDestination_id());
			prst.setString(3, confirm.getConfirm_date());
			ResultSet executeQuery = prst.executeQuery();
			if(executeQuery.next()){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public List<Confirm> getConfirmdList(Confirm confirm){
		List<Confirm> retList = new ArrayList<Confirm>();
		StringBuffer sqlString = new StringBuffer("select * from g_confirm");
		if(confirm.getStudent_id() != 0){
			sqlString.append(" and student_id = "+confirm.getStudent_id());
		}
		if(confirm.getDestination_id() != 0){
			sqlString.append(" and destination_id ="+confirm.getDestination_id());
		}
		if(!StringUtil.isEmpty(confirm.getConfirm_date())){
			sqlString.append(" and confirm_date like'%"+confirm.getConfirm_date()+"%'");
		}
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sqlString.toString().replaceFirst("and", "where"));
			ResultSet executeQuery = preparedStatement.executeQuery();
			while(executeQuery.next()){
				Confirm a = new Confirm();
				a.setId(executeQuery.getInt("id"));
				a.setStudent_id(executeQuery.getInt("student_id"));
				a.setDestination_id(executeQuery.getInt("destination_id"));
				a.setConfirm_date(executeQuery.getString("confirm_date"));
				retList.add(a);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return retList;
	}
	public boolean delete(int id){
		String sql = "delete from g_confirm where id=?";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setInt(1, id);
			if(preparedStatement.executeUpdate() > 0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public List<HashMap<Integer, String>> getConfirmStatsList(Integer destination_id,String dateString){
		List<HashMap<Integer, String>> retList = new ArrayList<HashMap<Integer,String>>();
		StringBuffer sqlString = new StringBuffer("select count(id) as confirm_num,confirm_date from g_confirm where destination_id = ? ");
		if(!StringUtil.isEmpty(dateString)){
			sqlString.append(" and confirm_date = '"+dateString + "'");
		}
		sqlString.append(" GROUP BY confirm_date");
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sqlString.toString());
			preparedStatement.setInt(1, destination_id);
			ResultSet executeQuery = preparedStatement.executeQuery();
			while(executeQuery.next()){
				HashMap<Integer, String> retMap = new HashMap<Integer, String>();
				retMap.put(executeQuery.getInt("confirm_num"), executeQuery.getString("confirm_date"));
				retList.add(retMap);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return retList;
	}
}
