package wbx.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import wbx.model.UNGradulation;
import wbx.model.Gradulation;
import wbx.model.StudentClass;
import wbx.util.StringUtil;

public class UNGradulationDao extends BaseDao {
	//�Ǳ�ҵ����¼
	public UNGradulation login(UNGradulation ungradulation) {
		String sql = "select * from ung_gradulation Where Gsname=? and password=?";
		UNGradulation ungradulationRst = null;
		try {
			//��SQL��䴫�����ݿ��������
			PreparedStatement prst = con.prepareStatement(sql);
			prst.setString(1, ungradulation.getGsname());
			prst.setString(2, ungradulation.getPassword());
			ResultSet executeQuery = prst.executeQuery();
			if(executeQuery.next()) {
				ungradulationRst = new UNGradulation();
				ungradulationRst.setGsno(executeQuery.getInt("Gsno"));
				ungradulationRst.setCno(executeQuery.getInt("Cno"));
				ungradulationRst.setGsname(executeQuery.getString("Gsname"));
				ungradulationRst.setPassword(executeQuery.getString("Password"));
				ungradulationRst.setSex(executeQuery.getString("Sex"));
			}
		} catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return ungradulationRst;
	}
	public boolean addUNGradulation(UNGradulation gstu) {
		String sql = "insert into ung_gradulation values(null,?,?,?,?)";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setString(1, gstu.getGsname());
			preparedStatement.setString(2, gstu.getPassword());
			preparedStatement.setInt(3, gstu.getCno());
			preparedStatement.setString(4, gstu.getSex());
			if(preparedStatement.executeUpdate() > 0) return true;
			
		} catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	
	public List<UNGradulation> getG_studentList(UNGradulation ungradulation) {
		List<UNGradulation> retList = new ArrayList<UNGradulation>();
		StringBuffer sqlString =new StringBuffer("select * from ung_gradulation");
		if(!StringUtil.isEmpty(ungradulation.getGsname())) {
			sqlString.append(" and Gsname like '%"+ungradulation.getGsname()+"%'");
		}
		if(ungradulation.getCno() != 0) {
			sqlString.append(" and Cno = "+ungradulation.getCno());
		}
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sqlString.toString().replaceFirst("and", "where"));
			ResultSet executeQuery = preparedStatement.executeQuery();
			while(executeQuery.next()) {
				UNGradulation gs = new UNGradulation();
				gs.setGsno(executeQuery.getInt("Gsno"));
				gs.setGsname(executeQuery.getString("Gsname"));
				gs.setSex(executeQuery.getString("Sex"));
				gs.setCno(executeQuery.getInt("Cno"));
				gs.setPassword(executeQuery.getString("Password"));
				retList.add(gs);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return retList;
	}
	
	public boolean delete(int cno) {
		String sql = "delete from ung_gradulation where Gsno=?";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setInt(1,cno);
			if(preparedStatement.executeUpdate() > 0) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}
	
	public boolean update(UNGradulation ungradulation) {
		String sql = "update ung_gradulation set Gsname=?, Password=?, Cno=? , Sex=? where Gsno=?";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setString(1,ungradulation.getGsname());
			preparedStatement.setString(2,ungradulation.getPassword());
			preparedStatement.setInt(3,ungradulation.getCno());
			preparedStatement.setString(4,ungradulation.getSex());
			preparedStatement.setInt(5,ungradulation.getGsno());
			if(preparedStatement.executeUpdate() > 0) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	public String editPassword(UNGradulation ungradulation,String newPassword){
		String sql = "select * from ung_gradulation where Gsno=? and Password=?";
		PreparedStatement prst = null;
		int id = 0;
		try {
			prst = con.prepareStatement(sql);
			prst.setInt(1, ungradulation.getGsno());
			prst.setString(2, ungradulation.getPassword());
			ResultSet executeQuery = prst.executeQuery();
			if(!executeQuery.next()){
				String retString = "ԭ�������";
				return retString;
			}
			id = executeQuery.getInt("Gsno");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}//��SQL��䴫�����ݿ��������
		String retString = "�޸�ʧ��";
		String sqlString = "update ung_gradulation set Password = ? where Gsno = ?";
		try {
			prst = con.prepareStatement(sqlString);
			prst.setString(1, newPassword);
			prst.setInt(2, id);
			int rst = prst.executeUpdate();
			if(rst > 0){
				retString = "�����޸ĳɹ���";
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}//��SQL��䴫�����ݿ��������
		return retString;
	}
}
