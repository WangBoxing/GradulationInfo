package wbx.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import wbx.model.Admin;
import wbx.model.Gradulation;
import wbx.model.StudentClass;
import wbx.util.StringUtil;

public class GradulationDao extends BaseDao {
	//��ҵ����¼
	public Gradulation login(Gradulation gradulation) {
		String sql = "select * from g_gradulation Where Gsname=? and password=?";
		Gradulation gradulationRst = null;
		try {
			//��SQL��䴫�����ݿ��������
			PreparedStatement prst = con.prepareStatement(sql);
			prst.setString(1, gradulation.getGsname());
			prst.setString(2, gradulation.getPassword());
			ResultSet executeQuery = prst.executeQuery();
			if(executeQuery.next()) {
				gradulationRst = new Gradulation();
				gradulationRst.setGsno(executeQuery.getInt("Gsno"));
				gradulationRst.setCno(executeQuery.getInt("Cno"));
				gradulationRst.setGsname(executeQuery.getString("Gsname"));
				gradulationRst.setPassword(executeQuery.getString("Password"));
				gradulationRst.setSex(executeQuery.getString("Sex"));
			}
		} catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return gradulationRst;
	}
	
	public boolean addGradulation(Gradulation gstu) {
		String sql = "insert into g_gradulation values(null,?,?,?,?)";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setString(1, gstu.getGsname());
			preparedStatement.setString(2, gstu.getPassword());
			preparedStatement.setInt(3, gstu.getCno());
			preparedStatement.setString(4, gstu.getSex());
			if(preparedStatement.executeUpdate() > 0) return true;
			
		} catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

	public List<Gradulation> getG_studentList(Gradulation gradulation) {
		List<Gradulation> retList = new ArrayList<Gradulation>();
		String sqlString ="select * from g_gradulation";
		if(!StringUtil.isEmpty(gradulation.getGsname())) {
			sqlString += " and Gsname like '%"+gradulation.getGsname()+"%'";
		}
		if(gradulation.getCno() != 0) {
			sqlString += " and Cno = "+gradulation.getCno();
		}
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sqlString.toString().replaceFirst("and", "where"));
			ResultSet executeQuery = preparedStatement.executeQuery();
			while(executeQuery.next()) {
				Gradulation gs = new Gradulation();
				gs.setGsno(executeQuery.getInt("Gsno"));
				gs.setGsname(executeQuery.getString("Gsname"));
				gs.setCno(executeQuery.getInt("Cno"));
				gs.setSex(executeQuery.getString("Sex"));
				gs.setPassword(executeQuery.getString("Password"));
				retList.add(gs);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return retList;
	}
	
//	public List<Gradulation> getG_studentList(Gradulation gradulation) {
//		List<Gradulation> retList = new ArrayList<Gradulation>();
//		StringBuffer sqlString =new StringBuffer("select * from g_gradulation");
//		if(!StringUtil.isEmpty(gradulation.getGsname())) {
//			sqlString.append(" and Gsname like '%"+gradulation.getGsname()+"%'");
//		}
//		if(gradulation.getCno() != 0) {
//			sqlString.append(" and Cno = "+gradulation.getCno());
//		}
//		try {
//			PreparedStatement preparedStatement = con.prepareStatement(sqlString.toString().replaceFirst("and", "where"));
//			ResultSet executeQuery = preparedStatement.executeQuery();
//			while(executeQuery.next()) {
//				Gradulation gs = new Gradulation();
//				gs.setGsno(executeQuery.getInt("Gsno"));
//				gs.setGsname(executeQuery.getString("Gsname"));
//				gs.setSex(executeQuery.getString("Sex"));
//				gs.setCno(executeQuery.getInt("Cno"));
//				gs.setPassword(executeQuery.getString("Password"));
//				retList.add(gs);
//			}
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		return retList;
//	}
	
	public boolean delete(int cno) {
		String sql = "delete from g_gradulation where Gsno=?";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setInt(1,cno);
			if(preparedStatement.executeUpdate() > 0) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}
	
	public boolean update(Gradulation gradulation) {
		String sql = "update g_gradulation set Gsname=?, Password=?, Cno=? , Sex=? where Gsno=?";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setString(1,gradulation.getGsname());
			preparedStatement.setString(2,gradulation.getPassword());
			preparedStatement.setInt(3,gradulation.getCno());
			preparedStatement.setString(4,gradulation.getSex());
			preparedStatement.setInt(5,gradulation.getGsno());
			if(preparedStatement.executeUpdate() > 0) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}
	public String editPassword(Gradulation gradulation,String newPassword){
		String sql = "select * from g_gradulation where Gsno=? and Password=?";
		PreparedStatement prst = null;
		int id = 0;
		try {
			prst = con.prepareStatement(sql);
			prst.setInt(1, gradulation.getGsno());
			prst.setString(2, gradulation.getPassword());
			ResultSet executeQuery = prst.executeQuery();
			if(!executeQuery.next()){
				String retString = "ԭ�������";
				return retString;
			}
			id = executeQuery.getInt("Gsno");
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}//��SQL��䴫�����ݿ��������
		String retString = "�޸�ʧ��";
		String sqlString = "update g_gradulation set Password = ? where Gsno = ?";
		try {
			prst = con.prepareStatement(sqlString);
			prst.setString(1, newPassword);
			prst.setInt(2, id);
			int rst = prst.executeUpdate();
			if(rst > 0){
				retString = "�����޸ĳɹ���";
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}//��SQL��䴫�����ݿ��������
		return retString;
	}
}
