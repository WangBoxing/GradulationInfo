package wbx.dao;

import wbx.model.StudentClass;
import wbx.util.StringUtil;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



//�༶��Ϣ�����ݿ�Ĳ���

public class ClassDao extends BaseDao {
	public boolean addClass(StudentClass sc) {
		String sql = "insert into g_class values(null,?,?,?)";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setString(1, sc.getCname());
			preparedStatement.setString(2, sc.getTname());
			preparedStatement.setString(3, sc.getInfo());
			if(preparedStatement.executeUpdate() > 0) return true;
			
		} catch(SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	
	public List<StudentClass> getClassList(StudentClass studentClass) {
		List<StudentClass> retList = new ArrayList<StudentClass>();
		String sqlString = "select * from g_class";
		if(!StringUtil.isEmpty(studentClass.getCname())) {
			sqlString += " where Cname like '%"+studentClass.getCname()+"%'";
		}
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sqlString);
			ResultSet executeQuery = preparedStatement.executeQuery();
			while(executeQuery.next()) {
				StudentClass sc = new StudentClass();
				sc.setCno(executeQuery.getInt("Cno"));
				sc.setCname(executeQuery.getString("Cname"));
				sc.setTname(executeQuery.getString("Tname"));
				sc.setInfo(executeQuery.getString("Info"));
				retList.add(sc);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return retList;
	}
	
	public boolean delete(int cno) {
		String sql = "delete from g_class where Cno=?";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setInt(1,cno);
			if(preparedStatement.executeUpdate() > 0) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}
	
	public boolean update(StudentClass sc) {
		String sql = "update g_class set Cname=?, Tname=?, Info=? where Cno=?";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setString(1,sc.getCname());
			preparedStatement.setString(2,sc.getTname());
			preparedStatement.setString(3,sc.getInfo());
			preparedStatement.setInt(4,sc.getCno());
			if(preparedStatement.executeUpdate() > 0) {
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}
}
