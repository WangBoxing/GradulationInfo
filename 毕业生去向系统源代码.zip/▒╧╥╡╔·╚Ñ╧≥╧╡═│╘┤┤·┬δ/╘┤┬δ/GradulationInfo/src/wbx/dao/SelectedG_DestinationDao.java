package wbx.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import wbx.model.G_Destination;
import wbx.model.SelectedG_Destination;
import wbx.model.Gradulation;

/**
 * 
 * @author llq
 *ѡ�α�����
 */
public class SelectedG_DestinationDao extends BaseDao {
	public boolean addSelectedG_Destination(SelectedG_Destination selectedG_Destination){
		String sql = "insert into g_selected_destination values(null,?,?)";
		try {
			java.sql.PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setInt(1, selectedG_Destination.getStudent_id());
			preparedStatement.setInt(2, selectedG_Destination.getDestination_id());
			if(preparedStatement.executeUpdate() > 0)return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public boolean updateSelectedG_Destination(SelectedG_Destination selectedG_Destination){
		String sql = "update g_selected_destination set student_id = ?,destination_id = ? where id = ?";
		try {
			java.sql.PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setInt(1, selectedG_Destination.getStudent_id());
			preparedStatement.setInt(2, selectedG_Destination.getDestination_id());
			preparedStatement.setInt(3, selectedG_Destination.getId());
			if(preparedStatement.executeUpdate() > 0)return true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public List<SelectedG_Destination> getSelectedG_DestinationList(SelectedG_Destination selectedG_Destination){
		List<SelectedG_Destination> retList = new ArrayList<SelectedG_Destination>();
		StringBuffer sqlString = new StringBuffer("select * from g_selected_destination");
		if(selectedG_Destination.getStudent_id() != 0){
			sqlString.append(" and student_id = "+selectedG_Destination.getStudent_id());
		}
		if(selectedG_Destination.getDestination_id() != 0){
			sqlString.append(" and destination_id ="+selectedG_Destination.getDestination_id());
		}
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sqlString.toString().replaceFirst("and", "where"));
			ResultSet executeQuery = preparedStatement.executeQuery();
			while(executeQuery.next()){
				SelectedG_Destination sg = new SelectedG_Destination();
				sg.setId(executeQuery.getInt("id"));
				sg.setStudent_id(executeQuery.getInt("student_id"));
				sg.setDestination_id(executeQuery.getInt("destination_id"));
				retList.add(sg);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return retList;
	}
	public boolean isSelected(SelectedG_Destination selectedG_Destination){
		String sql = "select * from g_selected_destination where student_id=? and destination_id = ?";
		try {
			PreparedStatement prst = con.prepareStatement(sql);//��sql��䴫�����ݿ��������
			prst.setInt(1, selectedG_Destination.getStudent_id());
			prst.setInt(2, selectedG_Destination.getDestination_id());
			ResultSet executeQuery = prst.executeQuery();
			if(executeQuery.next()){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public boolean delete(int id){
		String sql = "delete from g_selected_destination where id=?";
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sql);
			preparedStatement.setInt(1, id);
			if(preparedStatement.executeUpdate() > 0){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}
	public List<Gradulation> getSelectedG_DestinationStudentList(G_Destination g_Destination){
		List<Gradulation> retList = new ArrayList<Gradulation>();
		StringBuffer sqlString = new StringBuffer("select sc.destination_id,s.* from g_selected_destination sc , g_gradulation s where sc.student_id = s.Gsno and destination_id = ?");
		try {
			PreparedStatement preparedStatement = con.prepareStatement(sqlString.toString());
			preparedStatement.setInt(1, g_Destination.getId());
			ResultSet executeQuery = preparedStatement.executeQuery();
			while(executeQuery.next()){
				Gradulation g = new Gradulation();
				g.setGsno(executeQuery.getInt("Gsno"));
				g.setGsname(executeQuery.getString("Gsname"));
				g.setCno(executeQuery.getInt("Cno"));
				g.setSex(executeQuery.getString("Sex"));
				retList.add(g);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return retList;
	}
}
