package wbx.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.border.EmptyBorder;

import wbx.dao.AdminDao;
import wbx.dao.GradulationDao;
import wbx.dao.UNGradulationDao;
import wbx.model.Admin;
import wbx.model.Gradulation;
import wbx.model.UNGradulation;
import wbx.model.identity;
import wbx.util.StringUtil;

import java.awt.GridLayout;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginJFrame extends JFrame {

	private JPanel contentPane;
	private JTextField userNameTextField;
	private JPasswordField passwordTextField;
	private JComboBox identityComboBox;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginJFrame frame = new LoginJFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginJFrame() {
		setTitle("\u767B\u5F55\u754C\u9762");    //unicode����
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 711, 396);
		contentPane = new JPanel();
		contentPane.setForeground(Color.BLACK);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setLocationRelativeTo(null);
		JLabel lblNewLabel = new JLabel("\u6BD5\u4E1A\u751F\u53BB\u5411\u7BA1\u7406\u7CFB\u7EDF");
		lblNewLabel.setIcon(new ImageIcon(LoginJFrame.class.getResource("/image/logo.png")));
		lblNewLabel.setForeground(Color.DARK_GRAY);
		lblNewLabel.setFont(new Font("΢���ź�", Font.BOLD, 23));
		
		JLabel lblNewLabel_1 = new JLabel(" \u8D26 \u53F7\uFF1A");
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		lblNewLabel_1.setIcon(new ImageIcon(LoginJFrame.class.getResource("/image/\u8D26\u53F7\u56FE\u6807.png")));
		
		JLabel lblNewLabel_2 = new JLabel(" \u5BC6 \u7801\uFF1A");
		lblNewLabel_2.setIcon(new ImageIcon(LoginJFrame.class.getResource("/image/password.png")));
		lblNewLabel_2.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		userNameTextField = new JTextField();
		userNameTextField.setColumns(10);
		
		passwordTextField = new JPasswordField();
		passwordTextField.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel(" \u8EAB \u4EFD\uFF1A");
		lblNewLabel_3.setIcon(new ImageIcon(LoginJFrame.class.getResource("/image/\u89D2\u8272\u56FE\u6807.png")));
		lblNewLabel_3.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		identityComboBox = new JComboBox();
		identityComboBox.setModel(new DefaultComboBoxModel(new identity[] {identity.Graduates,identity.Nongraduates,identity.Admin}));
		identityComboBox.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		
		JButton loginBtnNewButton = new JButton(" \u767B \u5F55");
		loginBtnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				loginAct(act);
			}
		});
		loginBtnNewButton.setIcon(new ImageIcon(LoginJFrame.class.getResource("/image/\u767B\u9646\u56FE\u6807.png")));
		loginBtnNewButton.setFont(new Font("΢���ź�", Font.PLAIN, 13));
		
		JButton resetBtnNewButton = new JButton(" \u91CD \u7F6E");
		resetBtnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				resetValue(act);
			}
		});
		resetBtnNewButton.setIcon(new ImageIcon(LoginJFrame.class.getResource("/image/\u91CD\u7F6E\u56FE\u6807.png")));
		resetBtnNewButton.setFont(new Font("΢���ź�", Font.PLAIN, 13));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(173)
							.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 372, Short.MAX_VALUE))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addContainerGap(197, Short.MAX_VALUE)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
										.addComponent(lblNewLabel_3, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(lblNewLabel_2, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
										.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE))
									.addGap(9))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(loginBtnNewButton)
									.addPreferredGap(ComponentPlacement.RELATED)))
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
									.addComponent(identityComboBox, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(passwordTextField)
									.addComponent(userNameTextField, GroupLayout.DEFAULT_SIZE, 172, Short.MAX_VALUE))
								.addComponent(resetBtnNewButton))
							.addPreferredGap(ComponentPlacement.RELATED, 71, Short.MAX_VALUE)))
					.addGap(140))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 88, Short.MAX_VALUE)
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(userNameTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(30)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(passwordTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(30)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(lblNewLabel_3)
						.addComponent(identityComboBox, GroupLayout.PREFERRED_SIZE, 23, GroupLayout.PREFERRED_SIZE))
					.addGap(41)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(loginBtnNewButton)
						.addComponent(resetBtnNewButton))
					.addGap(43))
		);
		contentPane.setLayout(gl_contentPane);
	}

	protected void loginAct(ActionEvent act) {
		// TODO Auto-generated method stub
		String userName = userNameTextField.getText().toString();
		String password = passwordTextField.getText().toString();
		identity selectedItem = (identity)identityComboBox.getSelectedItem();
		//�����Ϊ��ʱ���ܵ�¼
		if(StringUtil.isEmpty(userName)) {
			//�����˺���ʾ��
			JOptionPane.showMessageDialog(this,"δ��д�˺ţ�");
		}
		if(StringUtil.isEmpty(password)) {
			//����������ʾ��
			JOptionPane.showMessageDialog(this,"δ��д���룡");
		}
		
		Admin admin = null;
		if("��ҵ��".equals(selectedItem.getName())) {
			//��ҵ����¼
			Gradulation gradulation = null;
			GradulationDao gradulationDao = new GradulationDao();
			Gradulation gradulationTmp = new Gradulation();
			gradulationTmp.setGsname(userName);
			gradulationTmp.setPassword(password);
			gradulation = gradulationDao.login(gradulationTmp);
			gradulationDao.closeDao();
			if(gradulation == null) {
				JOptionPane.showMessageDialog(this, "�û�������������");
				return;
			}
			JOptionPane.showMessageDialog(this, "[" + selectedItem.getName() + "] " + gradulation.getGsname() + "��¼�ɹ���");
			this.dispose();
			new MainJFrame(selectedItem,gradulation).setVisible(true);
		}else if("�Ǳ�ҵ��".equals(selectedItem.getName())) {
			//�Ǳ�ҵ����¼
			UNGradulation ungradulation = null;
			UNGradulationDao ungradulationDao = new UNGradulationDao();
			UNGradulation ungradulationTmp = new UNGradulation();
			ungradulationTmp.setGsname(userName);
			ungradulationTmp.setPassword(password);
			ungradulation = ungradulationDao.login(ungradulationTmp);
			ungradulationDao.closeDao();
			if(ungradulation == null) {
				JOptionPane.showMessageDialog(this, "�û�������������");
				return;
			}
			JOptionPane.showMessageDialog(this, "[" + selectedItem.getName() + "] " + ungradulation.getGsname() + "��¼�ɹ���");
			this.dispose();
			new MainJFrame(selectedItem,ungradulation).setVisible(true);
		}else if("����Ա".equals(selectedItem.getName())) {
			//����Ա��¼
			AdminDao adminDao = new AdminDao();
			Admin adminTmp = new Admin();
			adminTmp.setName(userName);
			adminTmp.setPassword(password);
			admin = adminDao.login(adminTmp);
			adminDao.closeDao();
			if(admin == null) {
				JOptionPane.showMessageDialog(this, "�û�������������");
				return;
			}
			JOptionPane.showMessageDialog(this, "[" + selectedItem.getName() + "] " + admin.getName() + "��¼�ɹ���");
			this.dispose();
			new MainJFrame(selectedItem,admin).setVisible(true);
		}
	}

	protected void resetValue(ActionEvent act) {
		// TODO Auto-generated method stub
		userNameTextField.setText("");
		passwordTextField.setText("");
		identityComboBox.setSelectedIndex(0);
	}
}
