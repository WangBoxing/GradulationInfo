package wbx.view;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import wbx.dao.ConfirmDao;
import wbx.dao.G_DestinationDao;
import wbx.dao.SelectedG_DestinationDao;
import wbx.dao.GradulationDao;
import wbx.model.Confirm;
import wbx.model.G_Destination;
import wbx.model.Gradulation;
import wbx.model.UNGradulation;
import wbx.util.DateFormatUtil;
import javax.swing.border.EtchedBorder;
import java.awt.Color;

public class ManageGStudentConfirmIFrame extends JInternalFrame {
	private JTable confirmListTable;
	private JComboBox g_DestinationComboBox ;
	private JComboBox gstudentComboBox;
	private List<Gradulation> gstudentList = new ArrayList<Gradulation>();
	private List<G_Destination> g_DestinationList = new ArrayList<G_Destination>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManageGStudentConfirmIFrame frame = new ManageGStudentConfirmIFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManageGStudentConfirmIFrame() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u786E\u8BA4\u7EDF\u8BA1\u7BA1\u7406");
		setBounds(100, 100, 712, 431);
		
		JLabel label = new JLabel(" \u5B66\u751F\uFF1A");
		label.setIcon(new ImageIcon(ManageGStudentConfirmIFrame.class.getResource("/image/\u5B66\u751F\u56FE\u6807.png")));
		label.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		gstudentComboBox = new JComboBox();
		gstudentComboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent ie) {
				gstudentChangedAct(ie);
			}
		});
		
		JLabel label_1 = new JLabel(" \u53BB\u5411\uFF1A");
		label_1.setIcon(new ImageIcon(ManageGStudentConfirmIFrame.class.getResource("/image/\u6BD5\u4E1A\u53BB\u5411\u7BA1\u7406\u56FE\u6807.png")));
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		g_DestinationComboBox = new JComboBox();
		g_DestinationComboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent ie) {
				g_DestinationChangedAct(ie);
			}
		});
		
		JButton confirmAddButton = new JButton("\u786E\u8BA4\u5DF2\u63D0\u4EA4");
		confirmAddButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				addConfirmAct(ae);
			}
		});
		confirmAddButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "\u5DF2\u786E\u8BA4\u5217\u8868", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(39)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(panel, Alignment.LEADING, 0, 0, Short.MAX_VALUE)
						.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
							.addComponent(label)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(gstudentComboBox, GroupLayout.PREFERRED_SIZE, 151, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(label_1)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(g_DestinationComboBox, GroupLayout.PREFERRED_SIZE, 133, GroupLayout.PREFERRED_SIZE)
							.addGap(44)
							.addComponent(confirmAddButton, GroupLayout.DEFAULT_SIZE, 105, Short.MAX_VALUE)))
					.addGap(96))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(26)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(gstudentComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_1)
						.addComponent(g_DestinationComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(confirmAddButton))
					.addGap(18)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 296, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(39, Short.MAX_VALUE))
		);
		
		JScrollPane scrollPane = new JScrollPane();
		
		JButton cancelButton = new JButton(" \u5220\u9664\u786E\u8BA4");
		cancelButton.setIcon(new ImageIcon(ManageGStudentConfirmIFrame.class.getResource("/image/\u5220\u9664.png")));
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				cancelConfirmAct(ae);
			}
		});
		cancelButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(scrollPane, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 605, Short.MAX_VALUE)
						.addComponent(cancelButton, GroupLayout.DEFAULT_SIZE, 605, Short.MAX_VALUE))
					.addContainerGap())
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 193, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(cancelButton)
					.addContainerGap(89, Short.MAX_VALUE))
		);
		
		confirmListTable = new JTable();
		confirmListTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u786E\u8BA4ID", "\u5B66\u751F\u59D3\u540D", "\u53BB\u5411", "\u786E\u8BA4\u65F6\u95F4"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setViewportView(confirmListTable);
		panel.setLayout(gl_panel);
		getContentPane().setLayout(groupLayout);
		setG_DestinationCombox();
		setGstudentCombox();
	}
	protected void cancelConfirmAct(ActionEvent ae) {
		// TODO Auto-generated method stub
		if(JOptionPane.showConfirmDialog(this, "ȷ��ɾ��ȷ����Ϣ��") != JOptionPane.OK_OPTION)return;
		int row = confirmListTable.getSelectedRow();
		if(row == -1){
			JOptionPane.showMessageDialog(this, "����ѡ��һ�����ݣ�");
			return;
		}
		int confirmId = Integer.parseInt(confirmListTable.getValueAt(row, 0).toString());
		ConfirmDao confirmDao = new ConfirmDao();
		if(confirmDao.delete(confirmId)){
			JOptionPane.showMessageDialog(this, "�ɹ�ɾ��ȷ����Ϣ��");
		}else{
			JOptionPane.showMessageDialog(this, "����ʧ�ܣ�");
		}
		setTable();
	}

	protected void addConfirmAct(ActionEvent ae) {
		// TODO Auto-generated method stub
		Gradulation gstudent = (Gradulation)gstudentComboBox.getSelectedItem();
		G_Destination g_Destination = (G_Destination)g_DestinationComboBox.getSelectedItem();
		String dateString = DateFormatUtil.getDateString(new Date(System.currentTimeMillis()), "yyyy-MM-dd");
		Confirm confirm = new Confirm();
		confirm.setConfirm_date(dateString);
		confirm.setStudent_id(gstudent.getGsno());
		confirm.setDestination_id(g_Destination.getId());
		ConfirmDao confirmDao = new ConfirmDao();
		if(confirmDao.isConfirmd(confirm)){
			JOptionPane.showMessageDialog(this, "��ȷ�ϣ������ظ�ȷ�ϣ�");
			return;
		}
		if(confirmDao.addConfirm(confirm)){
			JOptionPane.showMessageDialog(this, "ȷ�ϳɹ���");
		}else{
			JOptionPane.showMessageDialog(this, "ȷ��ʧ�ܣ�");
		}
		confirmDao.closeDao();
		setTable();
	}

	protected void gstudentChangedAct(ItemEvent ie) {
		// TODO Auto-generated method stub
		if(ie.getStateChange() == ItemEvent.SELECTED){
			setTable();
		}
	}

	protected void g_DestinationChangedAct(ItemEvent ie) {
		// TODO Auto-generated method stub
		if(ie.getStateChange() == ItemEvent.SELECTED){
			setGstudentCombox();
		}
			//JOptionPane.showMessageDialog(this, "�ı�");
	}

	private void setGstudentCombox(){
		Gradulation g = new Gradulation();
		gstudentComboBox.removeAllItems();
		GradulationDao gstudentDao = new GradulationDao();
		gstudentList = gstudentDao.getG_studentList(g);
		gstudentDao.closeDao();
		G_Destination g_Destination = (G_Destination)g_DestinationComboBox.getSelectedItem();
		List<Gradulation> selectedG_DestinationStudentList = getSelectedG_DestinationStudentList(g_Destination);
		for (Gradulation gstudent : gstudentList) {
			for(Gradulation gstudent2 : selectedG_DestinationStudentList){
				if(gstudent.getGsno() == gstudent2.getGsno())
					gstudentComboBox.addItem(gstudent);
			}
		}
		
	}
	private List<Gradulation> getSelectedG_DestinationStudentList(G_Destination g_Destination){
		SelectedG_DestinationDao scDao = new SelectedG_DestinationDao();
		List<Gradulation> selectedG_DestinationStudentList = scDao.getSelectedG_DestinationStudentList(g_Destination);
		return selectedG_DestinationStudentList;
	}
	private void setG_DestinationCombox(){
		G_DestinationDao g_DestinationDao = new G_DestinationDao();
		g_DestinationList = g_DestinationDao.getG_DestinationList(new G_Destination());
		g_DestinationDao.closeDao();
		for (G_Destination g_Destination : g_DestinationList) {
			if("�Ǳ�ҵ��".equals(MainJFrame.Identity.getName())){
//				UNGradulation teacher = (UNGradulation)MainJFrame.userObject;
//				if(g_Destination.getTeacher_id() == teacher.getId()){
					g_DestinationComboBox.addItem(g_Destination);
//				}
				continue;
			}
			//ִ�е�����һ���ǳ�������Ա����
			g_DestinationComboBox.addItem(g_Destination);
		}
		
	}
	private void setTable(){
		Gradulation gstudent = (Gradulation)gstudentComboBox.getSelectedItem();
		DefaultTableModel dft = (DefaultTableModel) confirmListTable.getModel();
		dft.setRowCount(0);
		ConfirmDao confirmDao = new ConfirmDao();
		Confirm confirm = new Confirm();
		confirm.setStudent_id(gstudent.getGsno());
		List<Confirm> confirmList = confirmDao.getConfirmdList(confirm);
		for (Confirm a : confirmList) {
			Vector v = new Vector();
			v.add(a.getId());
			v.add(gstudent.getGsname());
			v.add(getDestinationById(a.getDestination_id()));
			v.add(a.getConfirm_date());
			dft.addRow(v);
		}
		confirmDao.closeDao();
	}
	private G_Destination getDestinationById(int id){
		for (int i = 0; i < g_DestinationList.size(); i++) {
			if(id == g_DestinationList.get(i).getId())return g_DestinationList.get(i);
		}
		return null;
	}
	
}