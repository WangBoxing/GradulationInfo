package wbx.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import wbx.dao.UNGradulationDao;
import wbx.util.StringUtil;

import wbx.dao.ClassDao;
import wbx.model.UNGradulation;
import wbx.model.StudentClass;

import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Vector;
import java.awt.event.ActionEvent;

public class AddUNG_StudentIFrame extends JInternalFrame {

	private JPanel contentPane;
	private JTextField ung_studentNameTextField;
	private JPasswordField ung_studentPasswordTextField;
	private JComboBox studentClassComboBox;
	private ButtonGroup sexButtonGroup;
	private JRadioButton studentSexManRdBtn;
	private JRadioButton studentSexFemalRdBtn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddUNG_StudentIFrame frame = new AddUNG_StudentIFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddUNG_StudentIFrame() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u6DFB\u52A0\u6BD5\u4E1A\u751F");
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		JLabel lblNewLabel = new JLabel(" \u5B66\u751F\u59D3\u540D\uFF1A");
		lblNewLabel.setIcon(new ImageIcon(AddUNG_StudentIFrame.class.getResource("/image/\u5B66\u751F\u56FE\u6807.png")));
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		ung_studentNameTextField = new JTextField();
		ung_studentNameTextField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel(" \u6240\u5C5E\u73ED\u7EA7\uFF1A");
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		lblNewLabel_1.setIcon(new ImageIcon(AddUNG_StudentIFrame.class.getResource("/image/\u73ED\u7EA7\u7BA1\u7406.png")));
		
		studentClassComboBox = new JComboBox();
		studentClassComboBox.setModel(new DefaultComboBoxModel(new String[] {}));
		
		JLabel lblNewLabel_2 = new JLabel(" \u767B\u5F55\u5BC6\u7801\uFF1A");
		lblNewLabel_2.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		lblNewLabel_2.setIcon(new ImageIcon(AddUNG_StudentIFrame.class.getResource("/image/password.png")));
		
		ung_studentPasswordTextField = new JPasswordField();
		ung_studentPasswordTextField.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel(" \u5B66\u751F\u6027\u522B\uFF1A");
		lblNewLabel_3.setIcon(new ImageIcon(AddUNG_StudentIFrame.class.getResource("/image/\u6027\u522B\u56FE\u6807.png")));
		lblNewLabel_3.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		studentSexManRdBtn = new JRadioButton("\u7537");
		studentSexManRdBtn.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		studentSexFemalRdBtn = new JRadioButton("\u5973");
		studentSexFemalRdBtn.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		sexButtonGroup = new ButtonGroup();
		sexButtonGroup.add(studentSexManRdBtn);
		sexButtonGroup.add(studentSexFemalRdBtn);
		
		JButton submitBtn = new JButton("\u786E\u8BA4");
		submitBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				studentAddAct(act);
			}
		});
		submitBtn.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JButton resetBtn = new JButton("\u91CD\u7F6E");
		resetBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				resetValue(act);
			}
		});
		resetBtn.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(55)
					.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 139, GroupLayout.PREFERRED_SIZE)
					.addGap(19)
					.addComponent(ung_studentNameTextField, GroupLayout.PREFERRED_SIZE, 161, GroupLayout.PREFERRED_SIZE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(55)
					.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 123, GroupLayout.PREFERRED_SIZE)
					.addGap(35)
					.addComponent(ung_studentPasswordTextField, GroupLayout.PREFERRED_SIZE, 161, GroupLayout.PREFERRED_SIZE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(55)
					.addComponent(lblNewLabel_1)
					.addGap(53)
					.addComponent(studentClassComboBox, GroupLayout.PREFERRED_SIZE, 161, GroupLayout.PREFERRED_SIZE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(55)
					.addComponent(lblNewLabel_3, GroupLayout.PREFERRED_SIZE, 158, GroupLayout.PREFERRED_SIZE)
					.addComponent(studentSexManRdBtn, GroupLayout.PREFERRED_SIZE, 55, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(studentSexFemalRdBtn))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(77)
					.addComponent(submitBtn, GroupLayout.PREFERRED_SIZE, 80, GroupLayout.PREFERRED_SIZE)
					.addGap(88)
					.addComponent(resetBtn, GroupLayout.PREFERRED_SIZE, 84, GroupLayout.PREFERRED_SIZE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(28)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(3)
							.addComponent(ung_studentNameTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addGap(20)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_2)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(3)
							.addComponent(ung_studentPasswordTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_1)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(2)
							.addComponent(studentClassComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(4)
							.addComponent(lblNewLabel_3))
						.addComponent(studentSexManRdBtn)
						.addComponent(studentSexFemalRdBtn))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(submitBtn)
						.addComponent(resetBtn)))
		);
		contentPane.setLayout(gl_contentPane);
		setStudentClassInfo();
	}

	protected void resetValue(ActionEvent act) {
		// TODO Auto-generated method stub
		ung_studentNameTextField.setText("");
		ung_studentPasswordTextField.setText("");
		studentClassComboBox.setSelectedIndex(0);
		sexButtonGroup.clearSelection();
		studentSexManRdBtn.setSelected(true);
	}
	
	protected void studentAddAct(ActionEvent act) {
		// TODO Auto-generated method stub
		String studentNameString = ung_studentNameTextField.getText().toString();
		String studentPassword = ung_studentPasswordTextField.getText().toString();
		if(StringUtil.isEmpty(studentNameString)){
			JOptionPane.showMessageDialog(this, "����дѧ��������");
			return;
		}
		if(StringUtil.isEmpty(studentPassword)){
			JOptionPane.showMessageDialog(this, "����д���룡");
			return;
		}
		StudentClass sc = (StudentClass)studentClassComboBox.getSelectedItem();
		String sex = studentSexManRdBtn.isSelected() ? studentSexManRdBtn.getText() : studentSexFemalRdBtn.getText();
		UNGradulation ungradulation = new UNGradulation();
		ungradulation.setGsname(studentNameString);
		ungradulation.setCno(sc.getCno());
		ungradulation.setPassword(studentPassword);
		ungradulation.setSex(sex);
		UNGradulationDao ungradulationDao = new UNGradulationDao();
		if(ungradulationDao.addUNGradulation(ungradulation)){
			JOptionPane.showMessageDialog(this, "���ӳɹ���");
		}else{
			JOptionPane.showMessageDialog(this, "����ʧ�ܣ�");
		}
		resetValue(act);
	}
	
	private void setStudentClassInfo(){
		ClassDao classDao = new ClassDao();
		List<StudentClass> classList = classDao.getClassList(new StudentClass());
		//�������
		for (StudentClass sc : classList) {
			studentClassComboBox.addItem(sc);
		}
		classDao.closeDao();
	}

}
