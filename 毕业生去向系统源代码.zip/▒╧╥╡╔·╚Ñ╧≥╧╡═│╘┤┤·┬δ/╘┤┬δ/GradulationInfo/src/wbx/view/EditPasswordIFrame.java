package wbx.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import wbx.dao.AdminDao;
import wbx.dao.GradulationDao;
import wbx.dao.UNGradulationDao;
import wbx.model.Admin;
import wbx.model.Gradulation;
import wbx.model.UNGradulation;
import wbx.model.identity;
import wbx.util.StringUtil;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class EditPasswordIFrame extends JInternalFrame {

	private JPanel contentPane;
	private JTextField oldPasswordTextField;
	private JTextField newPasswordTextField;
	private JTextField confirmPasswordTextField;
	private JLabel currentUserLabel;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					EditPasswordJFrame frame = new EditPasswordJFrame();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public EditPasswordIFrame() {
		setTitle("\u4FEE\u6539\u5BC6\u7801");
		setBounds(100, 100, 451, 319);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setClosable(true);
		setIconifiable(true);
		JLabel lblNewLabel = new JLabel(" \u539F\u5BC6\u7801\uFF1A");
		lblNewLabel.setIcon(new ImageIcon(EditPasswordIFrame.class.getResource("/image/\u539F\u5BC6\u7801\u56FE\u6807.png")));
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		oldPasswordTextField = new JTextField();
		oldPasswordTextField.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel(" \u65B0\u5BC6\u7801\uFF1A");
		lblNewLabel_1.setIcon(new ImageIcon(EditPasswordIFrame.class.getResource("/image/\u65B0\u5BC6\u7801\u56FE\u6807.png")));
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		newPasswordTextField = new JTextField();
		newPasswordTextField.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel(" \u518D\u6B21\u786E\u8BA4\uFF1A");
		lblNewLabel_2.setIcon(new ImageIcon(EditPasswordIFrame.class.getResource("/image/\u518D\u6B21\u786E\u8BA4\u56FE\u6807.png")));
		lblNewLabel_2.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		confirmPasswordTextField = new JTextField();
		confirmPasswordTextField.setColumns(10);
		
		JButton submitBtn = new JButton("\u786E\u8BA4\u4FEE\u6539");
		submitBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				submitEdit(act);
			}
		});
		submitBtn.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JButton resetBtn = new JButton("\u91CD\u7F6E");
		resetBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				resetValue(act);
			}
		});
		resetBtn.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JLabel lblNewLabel_3 = new JLabel(" \u5F53\u524D\u7528\u6237\uFF1A");
		lblNewLabel_3.setIcon(new ImageIcon(EditPasswordIFrame.class.getResource("/image/\u5F53\u524D\u7528\u6237\u56FE\u6807.png")));
		lblNewLabel_3.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		currentUserLabel = new JLabel("");
		currentUserLabel.setFont(new Font("΢���ź�", Font.PLAIN, 16));
//		currentUserLabel.setEnabled(false);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(87)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblNewLabel_3)
							.addContainerGap())
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGap(115)
									.addComponent(currentUserLabel, GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblNewLabel_2)
										.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 93, GroupLayout.PREFERRED_SIZE)
										.addComponent(lblNewLabel_1))
									.addGap(10)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(oldPasswordTextField, GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)
										.addComponent(newPasswordTextField, 140, 140, 140)
										.addComponent(confirmPasswordTextField, GroupLayout.DEFAULT_SIZE, 140, Short.MAX_VALUE)))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(submitBtn)
									.addGap(71)
									.addComponent(resetBtn, GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)))
							.addGap(86))))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(20)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addComponent(currentUserLabel)
						.addComponent(lblNewLabel_3))
					.addGap(29)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(oldPasswordTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(30)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_1)
						.addComponent(newPasswordTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(30)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(confirmPasswordTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(26)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addComponent(resetBtn, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(submitBtn, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
					.addContainerGap(52, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
		if("����Ա".equals(MainJFrame.Identity.getName())) {
			Admin admin = (Admin)MainJFrame.userObject;
			currentUserLabel.setText("����Ա:  " + admin.getName());
		} else if("��ҵ��".equals(MainJFrame.Identity.getName())) {
			Gradulation gradulation = (Gradulation)MainJFrame.userObject;
			currentUserLabel.setText("��ҵ��: " + gradulation.getGsname());
		} else if("�Ǳ�ҵ��".equals(MainJFrame.Identity.getName())) {
			UNGradulation ungradulation = (UNGradulation)MainJFrame.userObject;
			currentUserLabel.setText("�Ǳ�ҵ��:  " + ungradulation.getGsname());
		}
		
	}

	protected void submitEdit(ActionEvent act) {
		// TODO Auto-generated method stub
		String oldPassword = oldPasswordTextField.getText().toString();
		String newPassword = newPasswordTextField.getText().toString();
		String confirmPassword = confirmPasswordTextField.getText().toString();
		if(StringUtil.isEmpty(oldPassword)) {
			JOptionPane.showMessageDialog(this, "δ��дԭ���룡");
			return;
		}
		if(StringUtil.isEmpty(newPassword)) {
			JOptionPane.showMessageDialog(this, "δ��д�����룡");
			return;
		}
		if(StringUtil.isEmpty(confirmPassword)) {
			JOptionPane.showMessageDialog(this, "δȷ�������룡");
			return;
		}
		if(newPassword.equals(oldPassword)) {
			JOptionPane.showMessageDialog(this, "�����벻����ԭ������ͬ��");
			return;
		}
		if(!newPassword.equals(confirmPassword)) {
			JOptionPane.showMessageDialog(this, "�����������벻һ�£�");
			return;
		}
		if("����Ա".equals(MainJFrame.Identity.getName())) {
			AdminDao adminDao = new AdminDao();
			Admin adminTmp = new Admin();
			Admin admin = (Admin)MainJFrame.userObject;
			adminTmp.setName(admin.getName());
			adminTmp.setPassword(oldPassword);
			JOptionPane.showMessageDialog(this, adminDao.editPassword(adminTmp, newPassword));
			adminDao.closeDao();
			return;
		}
		if("��ҵ��".equals(MainJFrame.Identity.getName())) {
			GradulationDao gradulationDao = new GradulationDao();
			Gradulation gradulationTmp = new Gradulation();
			Gradulation gradulation = (Gradulation)MainJFrame.userObject;
			gradulationTmp.setGsname(gradulation.getGsname());
			gradulationTmp.setPassword(oldPassword);
			gradulationTmp.setGsno(gradulation.getGsno());
			JOptionPane.showMessageDialog(this, gradulationDao.editPassword(gradulationTmp, newPassword));
			gradulationDao.closeDao();
			return;
		}
		if("�Ǳ�ҵ��".equals(MainJFrame.Identity.getName())) {
			UNGradulationDao ungradulationDao = new UNGradulationDao();
			UNGradulation ungradulationTmp = new UNGradulation();
			UNGradulation ungradulation = (UNGradulation)MainJFrame.userObject;
			ungradulationTmp.setGsname(ungradulation.getGsname());
			ungradulationTmp.setPassword(oldPassword);
			ungradulationTmp.setGsno(ungradulation.getGsno());
			JOptionPane.showMessageDialog(this, ungradulationDao.editPassword(ungradulationTmp, newPassword));
			ungradulationDao.closeDao();
			return;
		}

	}

	protected void resetValue(ActionEvent act) {
		// TODO Auto-generated method stub
		oldPasswordTextField.setText("");
		newPasswordTextField.setText("");
		confirmPasswordTextField.setText("");
	}
}
