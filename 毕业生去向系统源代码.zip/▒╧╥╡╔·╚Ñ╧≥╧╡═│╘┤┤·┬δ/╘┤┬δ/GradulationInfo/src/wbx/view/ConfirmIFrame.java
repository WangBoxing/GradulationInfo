package wbx.view;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import wbx.dao.ConfirmDao;
import wbx.dao.G_DestinationDao;
import wbx.dao.SelectedG_DestinationDao;
import wbx.model.Confirm;
import wbx.model.G_Destination;
import wbx.model.SelectedG_Destination;
import wbx.model.Gradulation;
import wbx.util.Chooser;
import wbx.util.DateFormatUtil;
import javax.swing.border.EtchedBorder;
import java.awt.Color;

public class ConfirmIFrame extends JInternalFrame {
	private JTextField searchConfirmDateTextField;
	private JTable confirmdListTable;
	private JComboBox addSelectedG_DestinationComboBox;
	private JComboBox searchSelectedComboBox;
	private List<G_Destination> g_DestinationList = new ArrayList<G_Destination>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ConfirmIFrame frame = new ConfirmIFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ConfirmIFrame() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u5B66\u751F\u786E\u8BA4\u9762\u677F");
		setBounds(100, 100, 686, 515);
		
		JLabel label = new JLabel(" \u53BB\u5411\uFF1A");
		label.setIcon(new ImageIcon(ConfirmIFrame.class.getResource("/image/\u6BD5\u4E1A\u53BB\u5411\u7BA1\u7406\u56FE\u6807.png")));
		label.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		addSelectedG_DestinationComboBox = new JComboBox();
		
		JButton addConfirmButton = new JButton("\u63D0\u4EA4\u786E\u8BA4");
		addConfirmButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				addConfirmAct(ae);
			}
		});
		addConfirmButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "\u5DF2\u786E\u8BA4\u5217\u8868", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addContainerGap(118, Short.MAX_VALUE)
					.addComponent(label)
					.addGap(18)
					.addComponent(addSelectedG_DestinationComboBox, GroupLayout.PREFERRED_SIZE, 123, GroupLayout.PREFERRED_SIZE)
					.addGap(123)
					.addComponent(addConfirmButton)
					.addGap(128))
				.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
					.addGap(49)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 573, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(70, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(23)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(addSelectedG_DestinationComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(addConfirmButton))
					.addGap(18)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 370, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(38, Short.MAX_VALUE))
		);
		
		JLabel label_1 = new JLabel(" \u53BB\u5411\uFF1A");
		label_1.setIcon(new ImageIcon(ConfirmIFrame.class.getResource("/image/\u6BD5\u4E1A\u53BB\u5411\u7BA1\u7406\u56FE\u6807.png")));
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		searchSelectedComboBox = new JComboBox();
		
		JLabel label_2 = new JLabel(" \u65E5\u671F\uFF1A");
		label_2.setIcon(new ImageIcon(ConfirmIFrame.class.getResource("/image/\u65E5\u671F.png")));
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		searchConfirmDateTextField = new JTextField();
		searchConfirmDateTextField.setColumns(10);
		
		JButton searchConfirmButton = new JButton("\u67E5\u8BE2");
		searchConfirmButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				searchAct(ae);
			}
		});
		searchConfirmButton.setIcon(new ImageIcon(ConfirmIFrame.class.getResource("/image/\u6570\u636E\u67E5\u8BE2,\u6570\u636E\u5E93\u67E5\u8BE2.png")));
		searchConfirmButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JScrollPane scrollPane = new JScrollPane();
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(scrollPane, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 506, Short.MAX_VALUE)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(label_1)
							.addGap(18)
							.addComponent(searchSelectedComboBox, GroupLayout.PREFERRED_SIZE, 123, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(label_2)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(searchConfirmDateTextField, GroupLayout.PREFERRED_SIZE, 110, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(searchConfirmButton)))
					.addContainerGap())
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(20)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_1)
						.addComponent(searchSelectedComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_2)
						.addComponent(searchConfirmDateTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(searchConfirmButton))
					.addGap(28)
					.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 261, Short.MAX_VALUE)
					.addContainerGap())
		);
		
		confirmdListTable = new JTable();
		confirmdListTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u786E\u8BA4ID", "\u5B66\u751F\u59D3\u540D", "\u53BB\u5411", "\u786E\u8BA4\u65E5\u671F"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setViewportView(confirmdListTable);
		panel.setLayout(gl_panel);
		getContentPane().setLayout(groupLayout);
		setG_DestinationCombox();
		initTable();
		Chooser.getInstance().register(searchConfirmDateTextField);
	}
	protected void searchAct(ActionEvent ae) {
		// TODO Auto-generated method stub
		Gradulation gradulation = (Gradulation)MainJFrame.userObject;
		G_Destination g_Destination = (G_Destination)searchSelectedComboBox.getSelectedItem();
		String dateString = searchConfirmDateTextField.getText().toString();
		Confirm confirm = new Confirm();
		confirm.setConfirm_date(dateString);
		confirm.setStudent_id(gradulation.getGsno());
		confirm.setDestination_id(g_Destination.getId());
		getConfirmdList(confirm);
	}

	protected void addConfirmAct(ActionEvent ae) {
		// TODO Auto-generated method stub
		Gradulation gradulation = (Gradulation)MainJFrame.userObject;
		G_Destination g_Destination = (G_Destination)addSelectedG_DestinationComboBox.getSelectedItem();
		String dateString = DateFormatUtil.getDateString(new Date(System.currentTimeMillis()), "yyyy-MM-dd");
		Confirm confirm = new Confirm();
		confirm.setConfirm_date(dateString);
		confirm.setStudent_id(gradulation.getGsno());
		confirm.setDestination_id(g_Destination.getId());
		ConfirmDao confirmDao = new ConfirmDao();
		if(confirmDao.isConfirmd(confirm)){
			JOptionPane.showMessageDialog(this, "�Ѿ�ȷ�ϣ������ظ�ȷ�ϣ�");
			return;
		}
		if(confirmDao.addConfirm(confirm)){
			JOptionPane.showMessageDialog(this, "ȷ�ϳɹ���");
		}else{
			JOptionPane.showMessageDialog(this, "ȷ��ʧ�ܣ�");
		}
		confirmDao.closeDao();
		initTable();
	}

	private void setG_DestinationCombox(){
		G_DestinationDao g_DestinationDao = new G_DestinationDao();
		g_DestinationList = g_DestinationDao.getG_DestinationList(new G_Destination());
		g_DestinationDao.closeDao();
		Gradulation gradulation = (Gradulation)MainJFrame.userObject;
		SelectedG_Destination sc = new SelectedG_Destination();
		sc.setStudent_id(gradulation.getGsno());
		SelectedG_DestinationDao scDao = new SelectedG_DestinationDao();
		List<SelectedG_Destination> selectedG_DestinationList = scDao.getSelectedG_DestinationList(sc);
		for (SelectedG_Destination selectedG_Destination : selectedG_DestinationList) {
			addSelectedG_DestinationComboBox.addItem(getG_DestinationById(selectedG_Destination.getDestination_id()));
			searchSelectedComboBox.addItem(getG_DestinationById(selectedG_Destination.getDestination_id()));
		}
	}
	private G_Destination getG_DestinationById(int id){
		for (int i = 0; i < g_DestinationList.size(); i++) {
			if(id == g_DestinationList.get(i).getId())return g_DestinationList.get(i);
		}
		return null;
	}
	private void initTable(){
		Gradulation gradulation = (Gradulation)MainJFrame.userObject;
		Confirm confirm = new Confirm();
		confirm.setStudent_id(gradulation.getGsno());
		getConfirmdList(confirm);
	}
	private void getConfirmdList(Confirm confirm){
		Gradulation gradulation = (Gradulation)MainJFrame.userObject;
		ConfirmDao confirmDao = new ConfirmDao();
		List<Confirm> confirmdList = confirmDao.getConfirmdList(confirm);
		DefaultTableModel dft = (DefaultTableModel) confirmdListTable.getModel();
		dft.setRowCount(0);
		for (Confirm a : confirmdList) {
			Vector v = new Vector();
			v.add(a.getId());
			v.add(gradulation.getGsname());
			v.add(getG_DestinationById(a.getDestination_id()));
			v.add(a.getConfirm_date());
			dft.addRow(v);
		}
		confirmDao.closeDao();
	}
	
}