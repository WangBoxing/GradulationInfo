package wbx.view;

import java.awt.EventQueue;
import java.awt.Font;
import java.util.List;
import java.util.Vector;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import wbx.dao.G_DestinationDao;
import wbx.dao.SalaryDao;
import wbx.dao.SelectedG_DestinationDao;
import wbx.dao.GradulationDao;
import wbx.model.G_Destination;
import wbx.model.Salary;
import wbx.model.Gradulation;
import wbx.model.UNGradulation;

import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.border.EtchedBorder;
import java.awt.Color;

public class ManageSalaryIFrame extends JInternalFrame {
	private JTable salaryListTable;
	private JTextField editSalaryTextField;
	private List<Gradulation>gradulationList;
	private JComboBox g_DestinationComboBox;
	private JComboBox gradulationComboBox;
	private List<G_Destination>g_DestinationList;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManageSalaryIFrame frame = new ManageSalaryIFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManageSalaryIFrame() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u85AA\u8D44\u7BA1\u7406\u754C\u9762");
		setBounds(100, 100, 731, 498);
		
		JLabel label = new JLabel(" \u5B66\u751F\uFF1A");
		label.setIcon(new ImageIcon(ManageSalaryIFrame.class.getResource("/image/\u6BD5\u4E1A\u751F\u7BA1\u7406\u56FE\u6807.png")));
		label.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		gradulationComboBox = new JComboBox();
		
		JLabel label_1 = new JLabel(" \u53BB\u5411\uFF1A");
		label_1.setIcon(new ImageIcon(ManageSalaryIFrame.class.getResource("/image/\u6BD5\u4E1A\u53BB\u5411\u7BA1\u7406\u56FE\u6807.png")));
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		g_DestinationComboBox = new JComboBox();
		g_DestinationComboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent ie) {
				g_DestinationChangedAct(ie);
			}
		});
		
		JButton searchButton = new JButton("\u67E5\u8BE2");
		searchButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				Gradulation gradulation = (Gradulation)gradulationComboBox.getSelectedItem();
				G_Destination g_Destination = (G_Destination)g_DestinationComboBox.getSelectedItem();
				Salary salary = new Salary();
				salary.setStudent_id(gradulation.getGsno());;
				salary.setDestination_id(g_Destination.getId());;
				setTable(salary);
			}
		});
		searchButton.setIcon(new ImageIcon(ManageSalaryIFrame.class.getResource("/image/\u6570\u636E\u67E5\u8BE2,\u6570\u636E\u5E93\u67E5\u8BE2.png")));
		searchButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JScrollPane scrollPane = new JScrollPane();
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "\u4FEE\u6539\u85AA\u8D44", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(58)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(label)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(gradulationComboBox, GroupLayout.PREFERRED_SIZE, 138, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(label_1)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(g_DestinationComboBox, GroupLayout.PREFERRED_SIZE, 129, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(searchButton))
						.addComponent(scrollPane)
						.addComponent(panel, GroupLayout.DEFAULT_SIZE, 604, Short.MAX_VALUE))
					.addGap(117))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(36)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(gradulationComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_1)
						.addComponent(g_DestinationComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(searchButton))
					.addGap(35)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 228, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 86, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(171, Short.MAX_VALUE))
		);
		
		JLabel label_2 = new JLabel(" \u85AA\u8D44\uFF08\u6708\u85AA\uFF09\uFF1A");
		label_2.setIcon(new ImageIcon(ManageSalaryIFrame.class.getResource("/image/\u671F\u671B\u85AA\u8D44.png")));
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		editSalaryTextField = new JTextField();
		editSalaryTextField.setColumns(10);
		
		JButton confirmEditButton = new JButton("\u786E\u8BA4\u4FEE\u6539");
		confirmEditButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				editSubmitAct(ae);
			}
		});
		confirmEditButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JButton deleteButton = new JButton("\u5220\u9664\u85AA\u8D44");
		deleteButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				deleteAct(ae);
			}
		});
		deleteButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(32)
					.addComponent(label_2)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(editSalaryTextField, GroupLayout.PREFERRED_SIZE, 130, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 59, Short.MAX_VALUE)
					.addComponent(confirmEditButton)
					.addGap(18)
					.addComponent(deleteButton)
					.addGap(23))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap(16, Short.MAX_VALUE)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_2)
						.addComponent(editSalaryTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(deleteButton)
						.addComponent(confirmEditButton))
					.addGap(20))
		);
		panel.setLayout(gl_panel);
		
		salaryListTable = new JTable();
		salaryListTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent me) {
				tableItemClick(me);
			}
		});
		salaryListTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u85AA\u8D44ID", "\u5B66\u751F\u59D3\u540D", "\u53BB\u5411", "\u85AA\u8D44\uFF08\u6708\u85AA\uFF09"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		salaryListTable.getColumnModel().getColumn(0).setPreferredWidth(57);
		scrollPane.setViewportView(salaryListTable);
		getContentPane().setLayout(groupLayout);
		setG_DestinationCombox();
		setGradulationCombox();
		initTable();
	}
	protected void deleteAct(ActionEvent ae) {
		// TODO Auto-generated method stub
		int row = salaryListTable.getSelectedRow();
		if(row == -1){
			JOptionPane.showMessageDialog(this, "����ѡ��һ�У�");
			return;
		}
		if(JOptionPane.showConfirmDialog(this, "ȷ��Ҫɾ����") == JOptionPane.OK_OPTION){
			int salaryId = Integer.parseInt(salaryListTable.getValueAt(row, 0).toString());
			SalaryDao salaryDao = new SalaryDao();
			if(salaryDao.delete(salaryId)){
				JOptionPane.showMessageDialog(this, "ɾ���ɹ���");
				editSalaryTextField.setText("");
				initTable();
			}else{
				JOptionPane.showMessageDialog(this, "ɾ��ʧ�ܣ�");
			}
			salaryDao.closeDao();
		}
	}

	protected void editSubmitAct(ActionEvent ae) {
		// TODO Auto-generated method stub
		int row = salaryListTable.getSelectedRow();
		if(row == -1){
			JOptionPane.showMessageDialog(this, "����ѡ��һ�У�");
			return;
		}
		int salaryId = Integer.parseInt(salaryListTable.getValueAt(row, 0).toString());
		int salary = Integer.parseInt(editSalaryTextField.getText().toString());
		SalaryDao salaryDao = new SalaryDao();
		if(salaryDao.update(salaryId, salary)){
			JOptionPane.showMessageDialog(this, "���³ɹ���");
			editSalaryTextField.setText("");
			initTable();
		}else{
			JOptionPane.showMessageDialog(this, "����ʧ�ܣ�");
		}
		salaryDao.closeDao();
	}

	protected void tableItemClick(MouseEvent me) {
		// TODO Auto-generated method stub
		String salary = (salaryListTable.getValueAt(salaryListTable.getSelectedRow(), 3).toString());
		editSalaryTextField.setText(salary);
	}

	protected void g_DestinationChangedAct(ItemEvent ie) {
		// TODO Auto-generated method stub
		if(ie.getStateChange() == ItemEvent.SELECTED){
			setGradulationCombox();
		}
	}

	private void setGradulationCombox(){
		gradulationComboBox.removeAllItems();
		GradulationDao gradulationDao = new GradulationDao();
		gradulationList = gradulationDao.getG_studentList(new Gradulation());
		gradulationDao.closeDao();
		G_Destination g_Destination = (G_Destination)g_DestinationComboBox.getSelectedItem();
		List<Gradulation> selectedG_DestinationGradulationList = getSelectedG_DestinationGradulationList(g_Destination);
		for (Gradulation gradulation : gradulationList) {
			for(Gradulation gradulation2 : selectedG_DestinationGradulationList){
				if(gradulation.getGsno() == gradulation2.getGsno())
					gradulationComboBox.addItem(gradulation);
			}
		}
		
	}
	private void setG_DestinationCombox(){
		G_DestinationDao g_DestinationDao = new G_DestinationDao();
		g_DestinationList = g_DestinationDao.getG_DestinationList(new G_Destination());
		g_DestinationDao.closeDao();
		for (G_Destination g_Destination : g_DestinationList) {
			if("�Ǳ�ҵ��".equals(MainJFrame.Identity.getName())){
//				UNGradulation uNGradulation = (UNGradulation)MainJFrame.userObject;
//				if(g_Destination.getUNGradulation_id() == uNGradulation.getId()){
					g_DestinationComboBox.addItem(g_Destination);
//				}
				continue;
			}
			//ִ�е�����һ���ǳ�������Ա����
			g_DestinationComboBox.addItem(g_Destination);
		}
		
	}
	private void initTable(){
		getSalaryList(new Salary());
	}
	private void setTable(Salary salary){
		getSalaryList(salary);
	}
	private void getSalaryList(Salary salary){
		SalaryDao salaryDao = new SalaryDao();
		List<Salary> salaryList = salaryDao.getSalaryList(salary);
		DefaultTableModel dft = (DefaultTableModel) salaryListTable.getModel();
		dft.setRowCount(0);
		for (Salary s : salaryList) {
			Vector v = new Vector();
			v.add(s.getId());
			v.add(getGradulationNameById(s.getStudent_id()));
			v.add(getG_DestinationById(s.getDestination_id()));
			v.add(s.getSalary());
			dft.addRow(v);
		}
		salaryDao.closeDao();
	}
	private G_Destination getG_DestinationById(int id){
		for (int i = 0; i < g_DestinationList.size(); i++) {
			if(id == g_DestinationList.get(i).getId())return g_DestinationList.get(i);
		}
		return null;
	}
	private List<Gradulation> getSelectedG_DestinationGradulationList(G_Destination g_Destination){
		SelectedG_DestinationDao scDao = new SelectedG_DestinationDao();
		List<Gradulation> selectedG_DestinationGradulationList = scDao.getSelectedG_DestinationStudentList(g_Destination);
		return selectedG_DestinationGradulationList;
	}
	private String getGradulationNameById(int id){
		for(Gradulation gradulation :gradulationList){
			if(gradulation.getGsno() == id)return gradulation.getGsname();
		}
		return null;
	}
}
