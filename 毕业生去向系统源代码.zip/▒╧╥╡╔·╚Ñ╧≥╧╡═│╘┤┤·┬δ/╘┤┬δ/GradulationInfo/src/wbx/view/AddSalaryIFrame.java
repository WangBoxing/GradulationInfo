package wbx.view;

import java.awt.EventQueue;
import java.awt.Font;
import java.util.List;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;

import wbx.dao.G_DestinationDao;
import wbx.dao.SalaryDao;
import wbx.dao.SelectedG_DestinationDao;
import wbx.dao.GradulationDao;
import wbx.model.G_Destination;
import wbx.model.Salary;
import wbx.model.Gradulation;
//import wbx.model.UNGradulation;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class AddSalaryIFrame extends JInternalFrame {
	private JTextField salaryTextField;
	private JComboBox gradulationComboBox;
	private JComboBox g_DestinationComboBox;
	private List<G_Destination> g_DestinationList;
	private List<Gradulation> gradulationList;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddSalaryIFrame frame = new AddSalaryIFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddSalaryIFrame() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u85AA\u8D44\u5F55\u5165\u754C\u9762");
		setBounds(100, 100, 472, 310);
		
		JLabel label = new JLabel(" \u5B66\u751F\u59D3\u540D\uFF1A");
		label.setIcon(new ImageIcon(AddSalaryIFrame.class.getResource("/image/\u6BD5\u4E1A\u751F\u7BA1\u7406\u56FE\u6807.png")));
		label.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		gradulationComboBox = new JComboBox();
		
		JLabel label_1 = new JLabel(" \u53BB\u5411\uFF1A");
		label_1.setIcon(new ImageIcon(AddSalaryIFrame.class.getResource("/image/\u6BD5\u4E1A\u53BB\u5411\u7BA1\u7406\u56FE\u6807.png")));
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		g_DestinationComboBox = new JComboBox();
		g_DestinationComboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent ae) {
				g_DestinationChangeAct(ae);
			}
		});
		g_DestinationComboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				
			}
		});
		
		JLabel label_2 = new JLabel("\u85AA\u8D44\uFF08\u6708\u85AA\uFF09\uFF1A");
		label_2.setIcon(new ImageIcon(AddSalaryIFrame.class.getResource("/image/\u671F\u671B\u85AA\u8D44.png")));
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		salaryTextField = new JTextField();
		salaryTextField.setColumns(10);
		
		JButton submitButton = new JButton("\u5F55\u5165\u85AA\u8D44");
		submitButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				submitAct(ae);
			}
		});
		submitButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addGroup(groupLayout.createSequentialGroup()
							.addContainerGap()
							.addComponent(submitButton))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(66)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(label_1)
									.addPreferredGap(ComponentPlacement.RELATED, 247, GroupLayout.PREFERRED_SIZE))
								.addGroup(groupLayout.createSequentialGroup()
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
										.addComponent(label)
										.addComponent(label_2))
									.addGap(10)
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
										.addComponent(gradulationComboBox, 0, 177, Short.MAX_VALUE)
										.addComponent(g_DestinationComboBox, 0, 177, Short.MAX_VALUE)
										.addComponent(salaryTextField, GroupLayout.PREFERRED_SIZE, 177, GroupLayout.PREFERRED_SIZE))))))
					.addGap(74))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(52)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(gradulationComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_1)
						.addComponent(g_DestinationComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(salaryTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_2))
					.addPreferredGap(ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
					.addComponent(submitButton)
					.addGap(44))
		);
		getContentPane().setLayout(groupLayout);
		setG_DestinationCombox();
		setGradulationCombox();
	}
	protected void submitAct(ActionEvent ae) {
		// TODO Auto-generated method stub
		int salary = 0;
		try {
			salary = Integer.parseInt(salaryTextField.getText().toString());
		} catch (Exception e) {
			// TODO: handle exception
			JOptionPane.showMessageDialog(this, "н�ʱ���Ϊ���ڻ����0��������");
			return;
		}
		if(salary < 0){
			JOptionPane.showMessageDialog(this, "н�ʱ���Ϊ���ڻ����0��������");
			return;
		}
		Gradulation gradulation = (Gradulation) gradulationComboBox.getSelectedItem();
		G_Destination g_Destination = (G_Destination)g_DestinationComboBox.getSelectedItem();
		Salary salaryObj = new Salary();
		salaryObj.setStudent_id(gradulation.getGsno());
		salaryObj.setDestination_id(g_Destination.getId());
		salaryObj.setSalary(salary);
		SalaryDao salaryDao = new SalaryDao();
		if(salaryDao.isAdd(salaryObj)){
			JOptionPane.showMessageDialog(this, "н���Ѿ�¼�룬�����ظ�¼�룡");
			return;
		}
		if(salaryDao.addSalary(salaryObj)){
			JOptionPane.showMessageDialog(this, "н��¼��ɹ���");
			salaryTextField.setText("");
		}else{
			JOptionPane.showMessageDialog(this, "н��¼��ʧ�ܣ�");
		}
		salaryDao.closeDao();
	}

	protected void g_DestinationChangeAct(ItemEvent ae) {
		// TODO Auto-generated method stub
		if(ae.getStateChange() == ItemEvent.SELECTED){
			setGradulationCombox();
		}
		//JOptionPane.showMessageDialog(this, "changed");
		//setGradulationCombox();
	}

	private void setG_DestinationCombox(){
		G_DestinationDao g_DestinationDao = new G_DestinationDao();
		g_DestinationList = g_DestinationDao.getG_DestinationList(new G_Destination());
		g_DestinationDao.closeDao();
		for (G_Destination g_Destination : g_DestinationList) {
			if("��ʦ".equals(MainJFrame.Identity.getName())){
//				UNGradulation uNGradulation = (UNGradulation)MainJFrame.userObject;
//				if(g_Destination.getUNGradulation_id() == uNGradulation.getId()){
					g_DestinationComboBox.addItem(g_Destination);
//				}
				continue;
			}
			//ִ�е�����һ���ǳ�������Ա����
			g_DestinationComboBox.addItem(g_Destination);
		}
		
	}
	private void setGradulationCombox(){
		gradulationComboBox.removeAllItems();
		GradulationDao gradulationDao = new GradulationDao();
		gradulationList = gradulationDao.getG_studentList(new Gradulation());
		gradulationDao.closeDao();
		G_Destination g_Destination = (G_Destination)g_DestinationComboBox.getSelectedItem();
		List<Gradulation> selectedG_DestinationGradulationList = getSelectedG_DestinationGradulationList(g_Destination);
		for (Gradulation gradulation : gradulationList) {
			for(Gradulation gradulation2 : selectedG_DestinationGradulationList){
				if(gradulation.getGsno() == gradulation2.getGsno())
					gradulationComboBox.addItem(gradulation);
			}
		}
		
	}
	private List<Gradulation> getSelectedG_DestinationGradulationList(G_Destination g_Destination){
		SelectedG_DestinationDao scDao = new SelectedG_DestinationDao();
		List<Gradulation> selectedG_DestinationStudentList = scDao.getSelectedG_DestinationStudentList(g_Destination);
		return selectedG_DestinationStudentList;
	}
}