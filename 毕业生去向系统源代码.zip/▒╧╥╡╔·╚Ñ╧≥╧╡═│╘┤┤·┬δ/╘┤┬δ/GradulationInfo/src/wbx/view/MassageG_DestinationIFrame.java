package wbx.view;

import java.awt.EventQueue;
import java.awt.Font;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import wbx.dao.G_DestinationDao;
import wbx.dao.GradulationDao;
import wbx.model.G_Destination;
import wbx.model.Gradulation;
import wbx.util.StringUtil;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.border.EtchedBorder;
import java.awt.Color;

public class MassageG_DestinationIFrame extends JInternalFrame {
	private JTextField searchG_DestinationNameTextField;
	private JTable g_DestinationListTable;
	private JTextField editG_DestinationTextField;
	private JTextArea editG_DestinationInfoTextArea;
	private List<Gradulation> teacherList = new ArrayList<Gradulation>();
	private JButton submitEditButton;
	private JButton deleteG_DestinationButton;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MassageG_DestinationIFrame frame = new MassageG_DestinationIFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public MassageG_DestinationIFrame() {
		setTitle("\u53BB\u5411\u4FE1\u606F\u7BA1\u7406");
		setBounds(100, 100, 605, 471);
		setClosable(true);
		setIconifiable(true);
		JLabel label = new JLabel(" \u6BD5\u4E1A\u65B9\u5411\uFF1A");
		label.setIcon(new ImageIcon(MassageG_DestinationIFrame.class.getResource("/image/\u6BD5\u4E1A\u53BB\u5411\u7BA1\u7406\u56FE\u6807.png")));
		label.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		searchG_DestinationNameTextField = new JTextField();
		searchG_DestinationNameTextField.setColumns(10);
		
		JButton searchButton = new JButton("\u67E5\u8BE2");
		searchButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				searchG_Destination(ae);
			}
		});
		searchButton.setIcon(new ImageIcon(MassageG_DestinationIFrame.class.getResource("/image/\u6570\u636E\u67E5\u8BE2,\u6570\u636E\u5E93\u67E5\u8BE2.png")));
		searchButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JScrollPane scrollPane = new JScrollPane();
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "\u7F16\u8F91\u53BB\u5411\u4FE1\u606F", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(34)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addComponent(scrollPane, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 462, Short.MAX_VALUE)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(label)
							.addGap(18)
							.addComponent(searchG_DestinationNameTextField, GroupLayout.PREFERRED_SIZE, 252, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addComponent(searchButton))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(panel, GroupLayout.PREFERRED_SIZE, 522, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)))
					.addGap(134))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(21)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(searchG_DestinationNameTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(searchButton))
					.addGap(18)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 180, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 164, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(22, Short.MAX_VALUE))
		);
		
		JLabel label_2 = new JLabel(" \u53BB\u5411\u540D\u79F0\uFF1A");
		label_2.setIcon(new ImageIcon(MassageG_DestinationIFrame.class.getResource("/image/\u6BD5\u4E1A\u53BB\u5411\u7BA1\u7406\u56FE\u6807.png")));
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		editG_DestinationTextField = new JTextField();
		editG_DestinationTextField.setColumns(10);
		
		JLabel label_5 = new JLabel(" \u53BB\u5411\u4ECB\u7ECD\uFF1A");
		label_5.setIcon(new ImageIcon(MassageG_DestinationIFrame.class.getResource("/image/\u601D\u8003.png")));
		label_5.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		editG_DestinationInfoTextArea = new JTextArea();
		
		submitEditButton = new JButton("\u786E\u8BA4\u4FEE\u6539");
		submitEditButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				editG_DestinationSubmit(ae);
			}
		});
		submitEditButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		deleteG_DestinationButton = new JButton("\u5220\u9664\u53BB\u5411");
		deleteG_DestinationButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				deleteG_Destination(ae);
			}
		});
		deleteG_DestinationButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addGap(19)
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING)
						.addComponent(label_5)
						.addComponent(label_2))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(editG_DestinationTextField, GroupLayout.DEFAULT_SIZE, 182, Short.MAX_VALUE)
						.addComponent(editG_DestinationInfoTextArea, GroupLayout.DEFAULT_SIZE, 182, Short.MAX_VALUE))
					.addGap(18)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addComponent(deleteG_DestinationButton)
						.addComponent(submitEditButton))
					.addGap(10))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_2)
						.addComponent(editG_DestinationTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(submitEditButton))
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(19)
							.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
								.addComponent(label_5)
								.addComponent(editG_DestinationInfoTextArea, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(37)
							.addComponent(deleteG_DestinationButton)))
					.addContainerGap(41, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		
		g_DestinationListTable = new JTable();
		g_DestinationListTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent me) {
				selectedG_Destination(me);
			}
		});
		g_DestinationListTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u53BB\u5411\u7F16\u53F7", "\u53BB\u5411\u540D\u79F0", "\u9009\u62E9\u4EBA\u6570", "\u53BB\u5411\u4ECB\u7ECD"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, true, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		g_DestinationListTable.getColumnModel().getColumn(0).setPreferredWidth(64);
		g_DestinationListTable.getColumnModel().getColumn(1).setPreferredWidth(94);
		g_DestinationListTable.getColumnModel().getColumn(2).setPreferredWidth(66);
		g_DestinationListTable.getColumnModel().getColumn(3).setPreferredWidth(264);
		scrollPane.setViewportView(g_DestinationListTable);
		getContentPane().setLayout(groupLayout);
//		setTeacherCombox();
		setG_DestinationListTable(new G_Destination());
		setAuthority();
	}
	protected void editG_DestinationSubmit(ActionEvent ae) {
		// TODO Auto-generated method stub
		int row = g_DestinationListTable.getSelectedRow();
		if(row == -1){
			JOptionPane.showMessageDialog(this, "��ѡ��Ҫ�޸ĵ����ݣ�");
			return;
		}
		int g_Destination_id = Integer.parseInt(g_DestinationListTable.getValueAt(row, 0).toString());
//		Teacher teacher = (Teacher) editCourseTeachComboBox.getSelectedItem();
		String g_DestinationName = editG_DestinationTextField.getText().toString();
		if(StringUtil.isEmpty(g_DestinationName)){
			JOptionPane.showMessageDialog(this, "�γ����Ʋ���Ϊ�գ�");
			return;
		}
//		int max_student_num = 0;
//		try {
//			max_student_num = Integer.parseInt(editCourseStudentNumTextField.getText().toString());
//		} catch (Exception e) {
//			// TODO: handle exception
//			JOptionPane.showMessageDialog(this, "ѧ���������������0��������");
//			return;
//		}
//		if(max_student_num <= 0){
//			JOptionPane.showMessageDialog(this, "ѧ���������������0��������");
//			return;
//		}
		String g_DestinationInfo = editG_DestinationInfoTextArea.getText().toString();
//		int selected_num = 0;
//		selected_num = Integer.parseInt(editG_DestinationStudentNumTextField.getText().toString());
		G_Destination g_Destination = new G_Destination();
		g_Destination.setId(g_Destination_id);
		g_Destination.setName(g_DestinationName);
//		g_Destination.setTeacher_id(teacher.getId());
//		course.setSelected_num(selected_num);
		g_Destination.setInfo(g_DestinationInfo);
		G_DestinationDao g_DestinationDao = new G_DestinationDao();
		if(g_DestinationDao.update(g_Destination)){
			JOptionPane.showMessageDialog(this, "�޸ĳɹ���");
		}else{
			JOptionPane.showMessageDialog(this, "�޸�ʧ�ܣ�");
		}
		g_DestinationDao.closeDao();
		setG_DestinationListTable(new G_Destination());
		//ˢ���޸Ŀ�
		editG_DestinationTextField.setText("");
		editG_DestinationInfoTextArea.setText("");
		
	}

	protected void selectedG_Destination(MouseEvent me) {
		// TODO Auto-generated method stub
		int row = g_DestinationListTable.getSelectedRow();
		String couseName = g_DestinationListTable.getValueAt(row, 1).toString();
//		int teacher_id = getTeacherIdByName(courseListTable.getValueAt(row, 2).toString());
//		int max_student_num = Integer.parseInt(courseListTable.getValueAt(row, 3).toString());
		String couseInfo = g_DestinationListTable.getValueAt(row, 3).toString();
		editG_DestinationTextField.setText(couseName);
//		editCourseStudentNumTextField.setText(max_student_num+"");
		editG_DestinationInfoTextArea.setText(couseInfo);
//		for(int i=0;i<editCourseTeachComboBox.getItemCount();i++){
//			Teacher t = (Teacher) editCourseTeachComboBox.getItemAt(i);
//			if(t.getId() == teacher_id){
//				editCourseTeachComboBox.setSelectedIndex(i);
//				break;
//			}
//		}
	}

	protected void searchG_Destination(ActionEvent ae) {
		// TODO Auto-generated method stub
		String searchG_DestinationName = searchG_DestinationNameTextField.getText().toString();
//		Teacher teacher = (Teacher) searchTeacherComboBox.getSelectedItem();
		G_Destination g_Destination = new G_Destination();
		g_Destination.setName(searchG_DestinationName);
//		g_Destination.setTeacher_id(teacher.getId());
		setG_DestinationListTable(g_Destination);
	}

	protected void deleteG_Destination(ActionEvent ae) {
		// TODO Auto-generated method stub
		if(JOptionPane.showConfirmDialog(this, "�Ƿ�ȷ��ɾ����") != JOptionPane.OK_OPTION){
			return;
		}
		int row = g_DestinationListTable.getSelectedRow();
		if(row == -1){
			JOptionPane.showMessageDialog(this, "��ѡ��Ҫɾ�������ݣ�");
			return;
		}
		int g_Destination_id = Integer.parseInt(g_DestinationListTable.getValueAt(row, 0).toString());
		G_DestinationDao g_DestinationDao = new G_DestinationDao();
		if(g_DestinationDao.delete(g_Destination_id)){
			JOptionPane.showMessageDialog(this, "ɾ���ɹ���");
		}else{
			JOptionPane.showMessageDialog(this, "ɾ��ʧ�ܣ�");
		}
		g_DestinationDao.closeDao();
		setG_DestinationListTable(new G_Destination());
		//ˢ���޸Ŀ�
		editG_DestinationTextField.setText("");
		editG_DestinationInfoTextArea.setText("");
	}

	private void setG_DestinationListTable(G_Destination g_Destination){
		G_DestinationDao g_DestinationDao = new G_DestinationDao();
		List<G_Destination> g_DestinationList = g_DestinationDao.getG_DestinationList(g_Destination);
		DefaultTableModel dft = (DefaultTableModel) g_DestinationListTable.getModel();
		dft.setRowCount(0);
		for (G_Destination c : g_DestinationList) {
			Vector v = new Vector();
			v.add(c.getId());
			v.add(c.getName());
//			v.add(getTeacherNameById(c.getTeacher_id()));
//			v.add(c.getMax_student_num());
			v.add(c.getSelected_num());
			v.add(c.getInfo());
			dft.addRow(v);
		}
		g_DestinationDao.closeDao();
	}
//	private void setTeacherCombox(){
//		TeacherDao teacherDao = new TeacherDao();
//		teacherList = teacherDao.getTeacherList(new Teacher());
//		teacherDao.closeDao();
//		for (Teacher teacher : teacherList) {
//			editCourseTeachComboBox.addItem(teacher);
//			searchTeacherComboBox.addItem(teacher);
//		}
//	}
//	private String getTeacherNameById(int teacher_id){
//		String retString = "";
//		for (Teacher teacher : teacherList) {
//			if(teacher.getId() == teacher_id){
//				retString = teacher.getName();
//				break;
//			}
//		}
//		return retString;
//	}
//	private int getTeacherIdByName(String teacher_name){
//		int retId = -1;
//		for (Teacher teacher : teacherList) {
//			if(teacher_name.equals(teacher.getName())){
//				retId = teacher.getId();
//				break;
//			}
//		}
//		return retId;
//	}
	
	private void setAuthority() {
		if("��ҵ��".equals(MainJFrame.Identity.getName())) {
			submitEditButton.setEnabled(false);
			deleteG_DestinationButton.setEnabled(false);
		}
		if("�Ǳ�ҵ��".equals(MainJFrame.Identity.getName())) {
			submitEditButton.setEnabled(false);
			deleteG_DestinationButton.setEnabled(false);
		}
//		if("����Ա".equals(MainJFrame.Identity.getName())) {
//			
//		}
	}
}
