package wbx.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.ScrollPane;
import java.awt.event.ActionEvent;
import java.awt.event.MouseEvent;
import java.util.List;
import java.util.Vector;

import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import wbx.dao.ClassDao;
import wbx.model.Gradulation;
import wbx.model.StudentClass;
import wbx.util.StringUtil;
import java.awt.event.ActionListener;
import javax.swing.JTextArea;
import java.awt.event.MouseAdapter;

public class ManageClassIFrame extends JInternalFrame {
	private JTextField searchClassNameTextField;
	private JTable classListTable;
	private JTextField editClassNameTextField;
	private JTextField editTeacherNameTextField;
	private JTextArea editClassInfoTextArea;
	private JButton submitDeleteBtn;
	private JButton submitEditBtn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManageClassIFrame frame = new ManageClassIFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManageClassIFrame() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u73ED\u7EA7\u4FE1\u606F\u7BA1\u7406");
		setBounds(100, 100, 642, 421);
		
		JLabel lblNewLabel = new JLabel(" \u73ED\u7EA7\u540D\u79F0\uFF1A");
		lblNewLabel.setIcon(new ImageIcon(ManageClassIFrame.class.getResource("/image/\u73ED\u7EA7\u7BA1\u7406.png")));
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		searchClassNameTextField = new JTextField();
		searchClassNameTextField.setColumns(10);
		
		JButton searchBtn = new JButton(" \u67E5\u8BE2");
		searchBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudentClass sc = new StudentClass();
				sc.setCname(searchClassNameTextField.getText().toString());
				setTable(sc);
			}
		});
		searchBtn.setIcon(new ImageIcon(ManageClassIFrame.class.getResource("/image/\u6570\u636E\u67E5\u8BE2,\u6570\u636E\u5E93\u67E5\u8BE2.png")));
		searchBtn.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JScrollPane scrollPane = new JScrollPane();
		
		JLabel lblNewLabel_1 = new JLabel(" \u73ED\u7EA7\u540D\u79F0\uFF1A");
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		lblNewLabel_1.setIcon(new ImageIcon(ManageClassIFrame.class.getResource("/image/\u73ED\u7EA7\u7BA1\u7406.png")));
		
		JLabel lblNewLabel_2 = new JLabel(" \u8BE6\u7EC6\u4FE1\u606F\uFF1A");
		lblNewLabel_2.setIcon(new ImageIcon(ManageClassIFrame.class.getResource("/image/img-daka.png")));
		lblNewLabel_2.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		editClassNameTextField = new JTextField();
		editClassNameTextField.setColumns(10);
		
		editClassInfoTextArea = new JTextArea();
		
		JLabel lblNewLabel_3 = new JLabel(" \u73ED\u4E3B\u4EFB\u59D3\u540D\uFF1A");
		lblNewLabel_3.setIcon(new ImageIcon(ManageClassIFrame.class.getResource("/image/\u5B66\u53F7\u7ED1\u5B9A.png")));
		lblNewLabel_3.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		editTeacherNameTextField = new JTextField();
		editTeacherNameTextField.setColumns(10);
		
		submitEditBtn = new JButton(" \u786E\u8BA4\u4FEE\u6539");
		submitEditBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				submitEditAct(act);
			}
		});
		submitEditBtn.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		submitEditBtn.setIcon(new ImageIcon(ManageClassIFrame.class.getResource("/image/\u786E\u8BA4\u63D0\u4EA4\u56FE\u6807.png")));
		
		submitDeleteBtn = new JButton(" \u786E\u8BA4\u5220\u9664");
		submitDeleteBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				submitDeleteAct(act);
			}
		});
		submitDeleteBtn.setIcon(new ImageIcon(ManageClassIFrame.class.getResource("/image/\u5220\u9664.png")));
		submitDeleteBtn.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(52)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(searchClassNameTextField, GroupLayout.PREFERRED_SIZE, 225, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 207, Short.MAX_VALUE)
							.addComponent(searchBtn, GroupLayout.PREFERRED_SIZE, 106, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
								.addComponent(scrollPane, GroupLayout.DEFAULT_SIZE, 592, Short.MAX_VALUE)
								.addGroup(groupLayout.createSequentialGroup()
									.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
										.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
											.addGroup(groupLayout.createSequentialGroup()
												.addComponent(lblNewLabel_2)
												.addGap(16))
											.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 113, GroupLayout.PREFERRED_SIZE))
										.addComponent(lblNewLabel_3))
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
										.addComponent(editClassNameTextField, GroupLayout.DEFAULT_SIZE, 233, Short.MAX_VALUE)
										.addComponent(editTeacherNameTextField)
										.addComponent(editClassInfoTextArea))
									.addPreferredGap(ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
									.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
										.addComponent(submitDeleteBtn)
										.addComponent(submitEditBtn))))
							.addGap(55)))
					.addContainerGap())
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(23)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(searchClassNameTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(searchBtn))
					.addGap(18)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 182, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(editClassNameTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel_1))
							.addGap(11)
							.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(editTeacherNameTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel_3))
							.addGap(18)
							.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(editClassInfoTextArea, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblNewLabel_2)))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(submitEditBtn, GroupLayout.PREFERRED_SIZE, 38, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(submitDeleteBtn, GroupLayout.PREFERRED_SIZE, 35, GroupLayout.PREFERRED_SIZE)))
					.addGap(18))
		);
		
		classListTable = new JTable();
		classListTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent me) {
				selectedTableRow(me);
			}
		});
		classListTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u73ED\u7EA7\u7F16\u53F7", "\u73ED\u7EA7\u540D\u79F0", "\u73ED\u4E3B\u4EFB\u59D3\u540D", "\u8BE6\u7EC6\u4FE1\u606F"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		classListTable.getColumnModel().getColumn(2).setPreferredWidth(79);
		classListTable.getColumnModel().getColumn(3).setPreferredWidth(262);
		scrollPane.setViewportView(classListTable);
		getContentPane().setLayout(groupLayout);
		setTable(new StudentClass());
		
		setAuthority();

	}

	protected void submitDeleteAct(ActionEvent act) {
		// TODO Auto-generated method stub
		if(JOptionPane.showConfirmDialog(this, "�Ƿ�ȷ��ɾ����") != JOptionPane.OK_OPTION){
			return;
		}
		int index = classListTable.getSelectedRow();
		if(index == -1){
			JOptionPane.showMessageDialog(this, "��ѡ��Ҫɾ��������!");
			return;
		}
		DefaultTableModel dft = (DefaultTableModel) classListTable.getModel();
		int cno = Integer.parseInt(dft.getValueAt(classListTable.getSelectedRow(), 0).toString());
		ClassDao classDao = new ClassDao();
		if(classDao.delete(cno)){
			JOptionPane.showMessageDialog(this, "ɾ���ɹ�!");
		}else{
			JOptionPane.showMessageDialog(this, "ɾ��ʧ��!");
		}
		
		//ˢ���޸Ŀ�
		editClassNameTextField.setText("");
		editTeacherNameTextField.setText("");
		editClassInfoTextArea.setText("");
		
		classDao.closeDao();
		setTable(new StudentClass());
	}

	protected void submitEditAct(ActionEvent act) {
		// TODO Auto-generated method stub
		ClassDao classDao = new ClassDao();
		int index = classListTable.getSelectedRow();
		if(index == -1){
			JOptionPane.showMessageDialog(this, "��ѡ��Ҫ�޸ĵ�����!");
			return;
		}
		DefaultTableModel dft = (DefaultTableModel) classListTable.getModel();
		String classCname = dft.getValueAt(classListTable.getSelectedRow(), 1).toString();
		String classTname = dft.getValueAt(classListTable.getSelectedRow(), 2).toString();
		String classInfo = dft.getValueAt(classListTable.getSelectedRow(), 3).toString();
		String editClassName = editClassNameTextField.getText().toString();
		String editTeacherName = editTeacherNameTextField.getText().toString();
		String editClassInfo = editClassInfoTextArea.getText().toString();
		if(StringUtil.isEmpty(editClassName)){
			JOptionPane.showMessageDialog(this, "����дҪ�޸ĵ�����!");
			return;
		}
		if(StringUtil.isEmpty(editTeacherName)){
			JOptionPane.showMessageDialog(this, "����дҪ�޸ĵİ���������!");
			return;
		}
		if(classCname.equals(editClassName) && classTname.equals(editTeacherName) && classInfo.equals(editClassInfo)){
			JOptionPane.showMessageDialog(this, "����û�����κ��޸�!");
			return;
		}
		int cno = Integer.parseInt(dft.getValueAt(classListTable.getSelectedRow(), 0).toString());
		StudentClass sc = new StudentClass();
		sc.setCno(cno);
		sc.setCname(editClassName);
		sc.setTname(editTeacherName);
		sc.setInfo(editClassInfo);
		if(classDao.update(sc)){
			JOptionPane.showMessageDialog(this, "���³ɹ�!");
		}else{
			JOptionPane.showMessageDialog(this, "����ʧ��!");
		}
		
		//ˢ���޸Ŀ�
		editClassNameTextField.setText("");
		editTeacherNameTextField.setText("");
		editClassInfoTextArea.setText("");
		
		classDao.closeDao();
		setTable(new StudentClass());
	}

	protected void selectedTableRow(MouseEvent me) {
		// TODO Auto-generated method stub
		DefaultTableModel dft = (DefaultTableModel) classListTable.getModel();
		editClassNameTextField.setText(dft.getValueAt(classListTable.getSelectedRow(), 1).toString());
		editTeacherNameTextField.setText(dft.getValueAt(classListTable.getSelectedRow(), 2).toString());
		editClassInfoTextArea.setText(dft.getValueAt(classListTable.getSelectedRow(), 3).toString());
	}

	private void setTable(StudentClass studentClass){
		DefaultTableModel dft = (DefaultTableModel) classListTable.getModel();
		dft.setRowCount(0);   //����б�
		ClassDao classDao = new ClassDao();
		List<StudentClass> classList = classDao.getClassList(studentClass);
		//�������
		for (StudentClass sc : classList) {
			Vector v = new Vector();
			v.add(sc.getCno());
			v.add(sc.getCname());
			v.add(sc.getTname());
			v.add(sc.getInfo());
			dft.addRow(v);
		}
		classDao.closeDao();
	}
	
	private void setAuthority() {
		if("��ҵ��".equals(MainJFrame.Identity.getName())) {
			submitDeleteBtn.setEnabled(false);
			submitEditBtn.setEnabled(false);
		}
		if("�Ǳ�ҵ��".equals(MainJFrame.Identity.getName())) {
			submitDeleteBtn.setEnabled(false);
			submitEditBtn.setEnabled(false);
		}
	}
}
