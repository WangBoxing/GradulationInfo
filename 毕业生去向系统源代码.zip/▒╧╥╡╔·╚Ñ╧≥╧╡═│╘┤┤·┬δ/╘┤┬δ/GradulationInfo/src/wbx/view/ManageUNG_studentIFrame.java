package wbx.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JScrollPane;
import java.awt.BorderLayout;

import javax.swing.ButtonGroup;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.ImageIcon;
import java.awt.Font;
import java.util.List;
import java.util.Vector;

import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import wbx.dao.ClassDao;
import wbx.dao.UNGradulationDao;
import wbx.model.UNGradulation;
import wbx.model.Gradulation;
import wbx.model.StudentClass;
import wbx.util.StringUtil;

import javax.swing.JRadioButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class ManageUNG_studentIFrame extends JInternalFrame {
	private JTextField searchStudentNameTextField;
	private JTable ung_studentListTable;
	private JPasswordField downloadPasswordTextField;
	private JTextField editStudentNameTextField;
	private JComboBox searchStudentClassComboBox;
	private JComboBox editStudentClassComboBox;
	private List<StudentClass> studentClassList;
	private ButtonGroup editSexButtonGroup;
	private JRadioButton editStudentSexManRdbtn;
	private JRadioButton editStudentSexFemalRdbtn;
	private JButton submitEditBtn ;
	private JButton deleteStudentBtn;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManageUNG_studentIFrame frame = new ManageUNG_studentIFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManageUNG_studentIFrame() {
		setClosable(true);
		setIconifiable(true);
		setTitle("�Ǳ�ҵ����Ϣ����");
		setBounds(100, 100, 711, 415);
		
		JScrollPane scrollPane = new JScrollPane();
		
		JLabel lblNewLabel = new JLabel("\u5B66\u751F\u59D3\u540D\uFF1A");
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		lblNewLabel.setIcon(new ImageIcon(ManageUNG_studentIFrame.class.getResource("/image/\u6BD5\u4E1A\u751F\u56FE\u6807.png")));
		
		searchStudentNameTextField = new JTextField();
		searchStudentNameTextField.setColumns(10);
		
		JButton searchBtn = new JButton("\u67E5\u8BE2");
		searchBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				searchStudent(act);
			}
		});
		searchBtn.setIcon(new ImageIcon(ManageUNG_studentIFrame.class.getResource("/image/\u6570\u636E\u67E5\u8BE2,\u6570\u636E\u5E93\u67E5\u8BE2.png")));
		searchBtn.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JLabel lblNewLabel_1 = new JLabel(" \u6240\u5C5E\u73ED\u7EA7\uFF1A");
		lblNewLabel_1.setIcon(new ImageIcon(ManageUNG_studentIFrame.class.getResource("/image/\u73ED\u7EA7\u7BA1\u7406\u56FE\u6807 (\u5927).png")));
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		searchStudentClassComboBox = new JComboBox();
		
		JLabel lblNewLabel_2 = new JLabel("\u5B66\u751F\u59D3\u540D\uFF1A");
		lblNewLabel_2.setIcon(new ImageIcon(ManageUNG_studentIFrame.class.getResource("/image/\u6BD5\u4E1A\u751F\u56FE\u6807.png")));
		lblNewLabel_2.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		JLabel lblNewLabel_3 = new JLabel(" \u6240\u5C5E\u73ED\u7EA7\uFF1A");
		lblNewLabel_3.setIcon(new ImageIcon(ManageUNG_studentIFrame.class.getResource("/image/\u73ED\u7EA7\u7BA1\u7406\u56FE\u6807 (\u5927).png")));
		lblNewLabel_3.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		JLabel lblNewLabel_4 = new JLabel(" \u5B66\u751F\u6027\u522B\uFF1A");
		lblNewLabel_4.setIcon(new ImageIcon(ManageUNG_studentIFrame.class.getResource("/image/\u6027\u522B\u56FE\u6807.png")));
		lblNewLabel_4.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		JLabel lblNewLabel_5 = new JLabel(" \u767B\u5F55\u5BC6\u7801\uFF1A");
		lblNewLabel_5.setIcon(new ImageIcon(ManageUNG_studentIFrame.class.getResource("/image/password.png")));
		lblNewLabel_5.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		editStudentClassComboBox = new JComboBox();
		
		editSexButtonGroup = new ButtonGroup();
		editStudentSexManRdbtn = new JRadioButton("\u7537");
		editStudentSexManRdbtn.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		editStudentSexFemalRdbtn = new JRadioButton("\u5973");
		editStudentSexFemalRdbtn.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		editSexButtonGroup.add(editStudentSexManRdbtn);
		editSexButtonGroup.add(editStudentSexFemalRdbtn);
		
		downloadPasswordTextField = new JPasswordField();
		downloadPasswordTextField.setColumns(10);
		
		editStudentNameTextField = new JTextField();
		editStudentNameTextField.setColumns(10);
		
		submitEditBtn = new JButton("\u786E\u8BA4\u4FEE\u6539");
		submitEditBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				submitEditAction(act);
			}
		});
		submitEditBtn.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		deleteStudentBtn = new JButton("\u5220\u9664\u5B66\u751F");
		deleteStudentBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				deleteStudent(act);
			}
		});
		deleteStudentBtn.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(53)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel_3)
								.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 115, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
								.addComponent(editStudentNameTextField)
								.addComponent(editStudentClassComboBox, GroupLayout.PREFERRED_SIZE, 115, GroupLayout.PREFERRED_SIZE))
							.addGap(18)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
								.addComponent(lblNewLabel_4, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(lblNewLabel_5))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
								.addGroup(groupLayout.createSequentialGroup()
									.addComponent(editStudentSexManRdbtn, GroupLayout.PREFERRED_SIZE, 52, GroupLayout.PREFERRED_SIZE)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(editStudentSexFemalRdbtn, GroupLayout.PREFERRED_SIZE, 58, GroupLayout.PREFERRED_SIZE))
								.addComponent(downloadPasswordTextField))
							.addGap(23)
							.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
								.addComponent(submitEditBtn, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)
								.addComponent(deleteStudentBtn, GroupLayout.PREFERRED_SIZE, 97, GroupLayout.PREFERRED_SIZE)))
						.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
							.addComponent(scrollPane, Alignment.LEADING)
							.addGroup(groupLayout.createSequentialGroup()
								.addComponent(lblNewLabel)
								.addPreferredGap(ComponentPlacement.UNRELATED)
								.addComponent(searchStudentNameTextField, GroupLayout.PREFERRED_SIZE, 101, GroupLayout.PREFERRED_SIZE)
								.addGap(32)
								.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 121, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED)
								.addComponent(searchStudentClassComboBox, GroupLayout.PREFERRED_SIZE, 112, GroupLayout.PREFERRED_SIZE)
								.addGap(31)
								.addComponent(searchBtn))))
					.addGap(342))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(27)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(searchStudentClassComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_1)
						.addComponent(searchStudentNameTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(searchBtn, GroupLayout.PREFERRED_SIZE, 27, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 193, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_2)
						.addComponent(editStudentNameTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_4)
						.addComponent(editStudentSexManRdbtn)
						.addComponent(editStudentSexFemalRdbtn)
						.addComponent(submitEditBtn))
					.addGap(18)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_3)
						.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
							.addComponent(editStudentClassComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(lblNewLabel_5)
							.addComponent(downloadPasswordTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
							.addComponent(deleteStudentBtn)))
					.addContainerGap(44, Short.MAX_VALUE))
		);
		
		ung_studentListTable = new JTable();
		ung_studentListTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent me) {
				selectedTableRow(me);
			}
		});
		ung_studentListTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u5B66\u751F\u7F16\u53F7", "\u5B66\u751F\u59D3\u540D", "\u5B66\u751F\u6027\u522B", "\u6240\u5C5E\u73ED\u7EA7", "\u767B\u5F55\u5BC6\u7801"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setViewportView(ung_studentListTable);
		getContentPane().setLayout(groupLayout);
		setStudentClassInfo();
		setTable(new UNGradulation());
		
		setAuthority();
	}
	
	protected void submitEditAction(ActionEvent act) {
		// TODO Auto-generated method stub
		int row = ung_studentListTable.getSelectedRow();
		if(row == -1) {
			JOptionPane.showMessageDialog(this,"��ѡ��Ҫ�޸ĵ����ݣ�");
			return;
		}
		String studentName = editStudentNameTextField.getText().toString();
		String studentPassword = downloadPasswordTextField.getText().toString();
		if(StringUtil.isEmpty(studentName)) {
			JOptionPane.showMessageDialog(this,"����д�޸ĺ��ѧ��������");
		}
		if(StringUtil.isEmpty(studentPassword)) {
			JOptionPane.showMessageDialog(this,"����д�޸ĺ�ĵ�¼���룡");
		}
		
		UNGradulation ungradulation = new UNGradulation();
		ungradulation.setGsname(studentName);
		ungradulation.setPassword(studentPassword);

		StudentClass sc = (StudentClass)editStudentClassComboBox.getSelectedItem();
		ungradulation.setCno(sc.getCno());
		ungradulation.setGsno(Integer.parseInt(ung_studentListTable.getValueAt(row, 0).toString()));
		if(editStudentSexManRdbtn.isSelected())ungradulation.setSex(editStudentSexManRdbtn.getText().toString());
		if(editStudentSexFemalRdbtn.isSelected())ungradulation.setSex(editStudentSexFemalRdbtn.getText().toString());

		UNGradulationDao ungradulationDao = new UNGradulationDao();
		if(ungradulationDao.update(ungradulation)) {
			JOptionPane.showMessageDialog(this,"���³ɹ���");
		} else {
			JOptionPane.showMessageDialog(this,"����ʧ�ܣ�");
		}
		ungradulationDao.closeDao();
		setTable(new UNGradulation());
		//ˢ���޸Ŀ�
		editStudentNameTextField.setText("");
		downloadPasswordTextField.setText("");
		editStudentSexManRdbtn.setSelected(true);
	}

	protected void deleteStudent(ActionEvent act) {
		// TODO Auto-generated method stub
		int row = ung_studentListTable.getSelectedRow();
		if(row == -1) {
			JOptionPane.showMessageDialog(this,"��ѡ��Ҫɾ�������ݣ�");
			return;
		}
		if(JOptionPane.showConfirmDialog(this, "��ȷ��ɾ��ô��") != JOptionPane.OK_OPTION){
			return;
		}
		UNGradulation ungradulation = new UNGradulation();
		ungradulation.setCno(Integer.parseInt(ung_studentListTable.getValueAt(row, 0).toString()));
		UNGradulationDao ungradulationDao = new UNGradulationDao();
		if(ungradulationDao.delete(Integer.parseInt(ung_studentListTable.getValueAt(row, 0).toString()))) {
			JOptionPane.showMessageDialog(this,"ɾ���ɹ���");
		} else {
			JOptionPane.showMessageDialog(this,"ɾ��ʧ�ܣ�");
		}
		ungradulationDao.closeDao();
		setTable(new UNGradulation());
		//ˢ���޸Ŀ�
		editStudentNameTextField.setText("");
		downloadPasswordTextField.setText("");
		editStudentSexManRdbtn.setSelected(true);
	}

	protected void selectedTableRow(MouseEvent me) {
		// TODO Auto-generated method stub
		DefaultTableModel dft = (DefaultTableModel) ung_studentListTable.getModel();
		editStudentNameTextField.setText(dft.getValueAt(ung_studentListTable.getSelectedRow(), 1).toString());
		String sex = dft.getValueAt(ung_studentListTable.getSelectedRow(), 2).toString();
		editSexButtonGroup.clearSelection();
		if(sex.equals(editStudentSexManRdbtn.getText())) editStudentSexManRdbtn.setSelected(true);
		if(sex.equals(editStudentSexFemalRdbtn.getText())) editStudentSexFemalRdbtn.setSelected(true);
		String className = dft.getValueAt(ung_studentListTable.getSelectedRow(), 3).toString();
		for(int i=0;i<editStudentClassComboBox.getItemCount();i++) {
			StudentClass sc = (StudentClass)editStudentClassComboBox.getItemAt(i);
			if(className.equals(sc.getCname())) {
				editStudentClassComboBox.setSelectedIndex(i);
			}
		}
		downloadPasswordTextField.setText(dft.getValueAt(ung_studentListTable.getSelectedRow(), 4).toString());
	}
	
	protected void searchStudent(ActionEvent act) {
		// TODO Auto-generated method stub
		UNGradulation ungradulation = new UNGradulation();
		ungradulation.setGsname(searchStudentNameTextField.getText().toString());
		StudentClass sc = (StudentClass)searchStudentClassComboBox.getSelectedItem();
		ungradulation.setCno(sc.getCno());
		setTable(ungradulation);
	}

	private void setTable(UNGradulation ungradulation){
		if("�Ǳ�ҵ��".equals(MainJFrame.Identity.getName())) {
			UNGradulation g = (UNGradulation)MainJFrame.userObject;
			ungradulation.setGsname(g.getGsname());
		}
		DefaultTableModel dft = (DefaultTableModel) ung_studentListTable.getModel();
		dft.setRowCount(0);   //����б�
		UNGradulationDao ungradulationDao = new UNGradulationDao();
		List<UNGradulation> g_studentList = ungradulationDao.getG_studentList(ungradulation);
		//�������
		for (UNGradulation gs : g_studentList) {
			if("��ҵ��".equals(MainJFrame.Identity.getName())) {
				Vector v = new Vector();
				v.add(gs.getGsno());
				v.add(gs.getGsname());
				v.add(gs.getSex());
				v.add(getClassNameByCno(gs.getCno()));
				v.add("******");
				dft.addRow(v);
			} else {
				Vector v = new Vector();
				v.add(gs.getGsno());
				v.add(gs.getGsname());
				v.add(gs.getSex());
				v.add(getClassNameByCno(gs.getCno()));
				v.add(gs.getPassword());
				dft.addRow(v);
			}

		}
		ungradulationDao.closeDao();
	}
	
	private void setStudentClassInfo(){
		ClassDao classDao = new ClassDao();
		studentClassList = classDao.getClassList(new StudentClass());
		//�������
		for (StudentClass sc : studentClassList) {
			searchStudentClassComboBox.addItem(sc);
			editStudentClassComboBox.addItem(sc);
		}
		classDao.closeDao();
	}
	
	private String getClassNameByCno(int cno) {
		for (StudentClass sc : studentClassList) {
			if(sc.getCno() == cno) return sc.getCname();
		}
		return "";
	}
	
	private void setAuthority() {
		if("��ҵ��".equals(MainJFrame.Identity.getName())) {
			deleteStudentBtn.setEnabled(false);
			submitEditBtn.setEnabled(false);
		}
		if("�Ǳ�ҵ��".equals(MainJFrame.Identity.getName())) {
			UNGradulation g = (UNGradulation)MainJFrame.userObject;
			searchStudentNameTextField.setText(g.getGsname());
			searchStudentNameTextField.setEditable(false);
			searchStudentClassComboBox.setEditable(false);
			deleteStudentBtn.setEnabled(false);
			for(int i=0;i<searchStudentClassComboBox.getItemCount();i++) {
				StudentClass sc =(StudentClass)searchStudentClassComboBox.getItemAt(i);
				if(sc.getCno() == g.getCno()) {
					searchStudentClassComboBox.setSelectedIndex(i);
					break;
				}
			}
			searchStudentClassComboBox.setEditable(false);
			for(int i=0;i<editStudentClassComboBox.getItemCount();i++) {
				StudentClass sc =(StudentClass)editStudentClassComboBox.getItemAt(i);
				if(sc.getCno() == g.getCno()) {
					editStudentClassComboBox.setSelectedIndex(i);
					break;
				}
			}
			editStudentClassComboBox.setEnabled(false);
		}
	}
}
