package wbx.view;

import java.awt.EventQueue;
import java.awt.Font;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.table.DefaultTableModel;

import wbx.dao.G_DestinationDao;
import wbx.dao.SalaryDao;
import wbx.dao.SelectedG_DestinationDao;
import wbx.model.Confirm;
import wbx.model.G_Destination;
import wbx.model.Salary;
import wbx.model.SelectedG_Destination;
import wbx.model.Gradulation;
import java.awt.event.ItemListener;
import java.awt.event.ItemEvent;

public class ViewSalaryIFrame extends JInternalFrame {
	private JTable salaryListTable;
	private JLabel gradulationNameLabel;
	private JComboBox g_DestinationComboBox;
	private List<G_Destination> g_DestinationList = new ArrayList<G_Destination>();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ViewSalaryIFrame frame = new ViewSalaryIFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ViewSalaryIFrame() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u4E2A\u4EBA\u85AA\u8D44\u67E5\u770B");
		setBounds(100, 100, 614, 403);
		
		JLabel label = new JLabel(" \u5B66\u751F\u59D3\u540D\uFF1A");
		label.setIcon(new ImageIcon(ViewSalaryIFrame.class.getResource("/image/\u6BD5\u4E1A\u751F\u7BA1\u7406\u56FE\u6807.png")));
		label.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		gradulationNameLabel = new JLabel("");
		gradulationNameLabel.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JLabel label_1 = new JLabel(" \u6240\u9009\u53BB\u5411\uFF1A");
		label_1.setIcon(new ImageIcon(ViewSalaryIFrame.class.getResource("/image/\u6BD5\u4E1A\u53BB\u5411\u7BA1\u7406\u56FE\u6807.png")));
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		g_DestinationComboBox = new JComboBox();
		g_DestinationComboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent ie) {
				g_DestinationChangedAct(ie);
			}
		});
		
		JScrollPane scrollPane = new JScrollPane();
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(61)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING, false)
						.addComponent(scrollPane, Alignment.LEADING)
						.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
							.addComponent(label)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(gradulationNameLabel, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
							.addGap(33)
							.addComponent(label_1)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(g_DestinationComboBox, GroupLayout.PREFERRED_SIZE, 129, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap(67, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(44)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(gradulationNameLabel)
						.addComponent(label_1)
						.addComponent(g_DestinationComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 224, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(63, Short.MAX_VALUE))
		);
		
		salaryListTable = new JTable();
		salaryListTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u85AA\u8D44ID", "\u5B66\u751F\u59D3\u540D", "\u53BB\u5411", "\u85AA\u8D44\uFF08\u6708\u85AA\uFF09"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				true, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		scrollPane.setViewportView(salaryListTable);
		getContentPane().setLayout(groupLayout);
		setG_DestinationCombox();
		initTable();
	}
	protected void g_DestinationChangedAct(ItemEvent ie) {
		// TODO Auto-generated method stub
		setTable();
	}

	private void setG_DestinationCombox(){
		G_DestinationDao g_DestinationDao = new G_DestinationDao();
		g_DestinationList = g_DestinationDao.getG_DestinationList(new G_Destination());
		g_DestinationDao.closeDao();
		Gradulation gradulation = (Gradulation)MainJFrame.userObject;
		gradulationNameLabel.setText(gradulation.getGsname());
		SelectedG_Destination sc = new SelectedG_Destination();
		sc.setStudent_id(gradulation.getGsno());
		SelectedG_DestinationDao scDao = new SelectedG_DestinationDao();
		List<SelectedG_Destination> selectedG_DestinationList = scDao.getSelectedG_DestinationList(sc);
		for (SelectedG_Destination selectedG_Destination : selectedG_DestinationList) {
			g_DestinationComboBox.addItem(getG_DestinationById(selectedG_Destination.getDestination_id()));
		}
	}
	private G_Destination getG_DestinationById(int id){
		for (int i = 0; i < g_DestinationList.size(); i++) {
			if(id == g_DestinationList.get(i).getId())return g_DestinationList.get(i);
		}
		return null;
	}
	private void initTable(){
		Gradulation gradulation = (Gradulation)MainJFrame.userObject;
		//G_Destination g_Destination = (G_Destination)g_DestinationComboBox.getSelectedItem();
		Salary salary = new Salary();
		salary.setStudent_id(gradulation.getGsno());
		//salary.setG_Destination_id(g_Destination.getId());
		getSalaryList(salary);
	}
	private void setTable(){
		Gradulation gradulation = (Gradulation)MainJFrame.userObject;
		G_Destination g_Destination = (G_Destination)g_DestinationComboBox.getSelectedItem();
		Salary salary = new Salary();
		salary.setStudent_id(gradulation.getGsno());
		salary.setDestination_id(g_Destination.getId());
		getSalaryList(salary);
	}
	private void getSalaryList(Salary salary){
		Gradulation gradulation = (Gradulation)MainJFrame.userObject;
		SalaryDao salaryDao = new SalaryDao();
		List<Salary> salaryList = salaryDao.getSalaryList(salary);
		DefaultTableModel dft = (DefaultTableModel) salaryListTable.getModel();
		dft.setRowCount(0);
		for (Salary s : salaryList) {
			Vector v = new Vector();
			v.add(s.getId());
			v.add(gradulation.getGsname());
			v.add(getG_DestinationById(s.getDestination_id()));
			v.add(s.getSalary());
			dft.addRow(v);
		}
		salaryDao.closeDao();
	}
}