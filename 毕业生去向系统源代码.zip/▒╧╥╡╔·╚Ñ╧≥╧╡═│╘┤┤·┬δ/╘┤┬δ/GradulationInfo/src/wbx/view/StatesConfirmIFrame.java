package wbx.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import wbx.dao.ConfirmDao;
import wbx.dao.G_DestinationDao;
import wbx.model.G_Destination;
//import wbx.model.Teacher;
import wbx.util.Chooser;
import wbx.util.StringUtil;
import javax.swing.border.EtchedBorder;
import java.awt.Color;

public class StatesConfirmIFrame extends JInternalFrame {
	private JTextField dateTextField;
	private JTable statsListTable;
	private List<G_Destination> g_DestinationList = new ArrayList<G_Destination>();
	private JComboBox g_DestinationComboBox;
	private JScrollPane statsListScrollPane;
	private JPanel statsListPanel;
	private ChartPanel chartPanel ;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StatesConfirmIFrame frame = new StatesConfirmIFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StatesConfirmIFrame() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u786E\u8BA4\u4FE1\u606F\u7EDF\u8BA1\u60C5\u51B5");
		setBounds(100, 100, 714, 487);
		
		JLabel label = new JLabel(" \u53BB\u5411\uFF1A");
		label.setIcon(new ImageIcon(StatesConfirmIFrame.class.getResource("/image/\u6BD5\u4E1A\u53BB\u5411\u7BA1\u7406\u56FE\u6807.png")));
		label.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		g_DestinationComboBox = new JComboBox();
		g_DestinationComboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent ie) {
				g_DestinationChangedAct(ie);
			}
		});
		
		JLabel label_1 = new JLabel("\u65E5\u671F\uFF1A");
		label_1.setIcon(new ImageIcon(StatesConfirmIFrame.class.getResource("/image/\u65E5\u671F.png")));
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		dateTextField = new JTextField();
		dateTextField.setColumns(10);
		
		JButton searchButton = new JButton("\u67E5\u8BE2");
		searchButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				searchConfirmAct(ae);
			}
		});
		searchButton.setIcon(new ImageIcon(StatesConfirmIFrame.class.getResource("/image/\u6570\u636E\u67E5\u8BE2,\u6570\u636E\u5E93\u67E5\u8BE2.png")));
		searchButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		statsListPanel = new JPanel();
		statsListPanel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "\u786E\u8BA4\u4FE1\u606F\u7EDF\u8BA1\u60C5\u51B5", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "\u5207\u6362\u663E\u793A\u65B9\u5F0F", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
							.addGap(58)
							.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, 586, Short.MAX_VALUE))
						.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
							.addGap(60)
							.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
								.addComponent(statsListPanel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
									.addComponent(label)
									.addGap(18)
									.addComponent(g_DestinationComboBox, GroupLayout.PREFERRED_SIZE, 135, GroupLayout.PREFERRED_SIZE)
									.addGap(27)
									.addComponent(label_1)
									.addPreferredGap(ComponentPlacement.RELATED)
									.addComponent(dateTextField, GroupLayout.PREFERRED_SIZE, 150, GroupLayout.PREFERRED_SIZE)
									.addGap(27)
									.addComponent(searchButton)))))
					.addGap(58))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(36)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(g_DestinationComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(label_1)
						.addComponent(dateTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(searchButton))
					.addGap(18)
					.addComponent(statsListPanel, GroupLayout.PREFERRED_SIZE, 270, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panel_1, GroupLayout.DEFAULT_SIZE, 83, Short.MAX_VALUE)
					.addGap(72))
		);
		
		JButton button = new JButton("\u5217\u8868\u663E\u793A");
		button.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//�б���ʾ
				clearPanel();
				statsListPanel.setLayout(new BorderLayout());
				statsListPanel.add(statsListScrollPane);
			}
		});
		button.setIcon(new ImageIcon(StatesConfirmIFrame.class.getResource("/image/\u5217\u8868 (1).png")));
		
		JButton button_1 = new JButton("\u67F1\u72B6\u56FE\u663E\u793A");
		button_1.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String dateString = dateTextField.getText().toString();
				if(StringUtil.isEmpty(dateString)){
					JOptionPane.showMessageDialog(StatesConfirmIFrame.this, "��ѡ������!");
					return;
				}
				//��״ͼ��ʾ
				clearPanel();
				G_Destination g_Destination = (G_Destination)g_DestinationComboBox.getSelectedItem();
				drawBar(getConfirmNum(g_Destination, dateString),g_Destination.getSelected_num(),dateString);
			}
		});
		button_1.setIcon(new ImageIcon(StatesConfirmIFrame.class.getResource("/image/\u65E5\u671F\u7EDF\u8BA1.png")));
		
		JButton button_2 = new JButton("\u997C\u72B6\u56FE\u663E\u793A");
		button_2.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				//��״ͼ��ʾ
				String dateString = dateTextField.getText().toString();
				if(StringUtil.isEmpty(dateString)){
					JOptionPane.showMessageDialog(StatesConfirmIFrame.this, "��ѡ������!");
					return;
				}
				//��״ͼ��ʾ
				clearPanel();
				G_Destination g_Destination = (G_Destination)g_DestinationComboBox.getSelectedItem();
				drawCircle(getConfirmNum(g_Destination, dateString),g_Destination.getSelected_num(),dateString);
			}
		});
		button_2.setIcon(new ImageIcon(StatesConfirmIFrame.class.getResource("/image/\u997C\u72B6\u56FE (1).png")));
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addGap(45)
					.addComponent(button)
					.addGap(64)
					.addComponent(button_1)
					.addGap(57)
					.addComponent(button_2)
					.addGap(128))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(button_1)
						.addComponent(button)
						.addComponent(button_2))
					.addContainerGap(30, Short.MAX_VALUE))
		);
		panel_1.setLayout(gl_panel_1);
		
		statsListScrollPane = new JScrollPane();
		GroupLayout gl_statsListPanel = new GroupLayout(statsListPanel);
		gl_statsListPanel.setHorizontalGroup(
			gl_statsListPanel.createParallelGroup(Alignment.LEADING)
				.addComponent(statsListScrollPane, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 572, Short.MAX_VALUE)
		);
		gl_statsListPanel.setVerticalGroup(
			gl_statsListPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_statsListPanel.createSequentialGroup()
					.addContainerGap()
					.addComponent(statsListScrollPane, GroupLayout.PREFERRED_SIZE, 221, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(27, Short.MAX_VALUE))
		);
		
		statsListTable = new JTable();
		statsListTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u53BB\u5411\u540D\u79F0", "\u786E\u8BA4\u4EBA\u6570", "\u672A\u786E\u8BA4\u4EBA\u6570", "\u9009\u62E9\u4EBA\u6570", "\u65E5\u671F"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		statsListScrollPane.setViewportView(statsListTable);
		statsListPanel.setLayout(gl_statsListPanel);
		getContentPane().setLayout(groupLayout);
		Chooser.getInstance().register(dateTextField);
		setG_DestinationCombox();
		setTable();
	}
	protected void drawCircle(int confirmNum, int selected_num,
			String dateString) {
		// TODO Auto-generated method stub
		setLanuage();
		DefaultPieDataset dataSet = new DefaultPieDataset();//�������ݼ�
		dataSet.setValue("��ȷ��",confirmNum);//��������
		dataSet.setValue("δȷ��",selected_num-confirmNum);
		dataSet.setValue("������",selected_num);
		JFreeChart chart = ChartFactory.createPieChart3D("��ҵ��ȷ��ͳ��", dataSet, true, true, false);
		chartPanel = new ChartPanel(chart);
		chartPanel.setPreferredSize(new Dimension(450,220));
		statsListPanel.add(chartPanel,BorderLayout.CENTER);
		statsListPanel.setLayout(new FlowLayout());
		statsListPanel.updateUI();
		statsListPanel.repaint();
	}

	protected void g_DestinationChangedAct(ItemEvent ie) {
		// TODO Auto-generated method stub
		if(ie.getStateChange() == ItemEvent.SELECTED){
			setTable();
		}
	}

	private void searchConfirmAct(ActionEvent ae){
		setTable();
	}
	private void setG_DestinationCombox(){
		G_DestinationDao g_DestinationDao = new G_DestinationDao();
		g_DestinationList = g_DestinationDao.getG_DestinationList(new G_Destination());
		g_DestinationDao.closeDao();
		for (G_Destination g_Destination : g_DestinationList) {
			if("�Ǳ�ҵ��".equals(MainJFrame.Identity.getName())){
//				Teacher teacher = (Teacher)MainFrm.userObject;
//				if(g_Destination.getTeacher_id() == teacher.getId()){
					g_DestinationComboBox.addItem(g_Destination);
//				}
				continue;
			}
			//ִ�е�����һ���ǳ�������Ա����
			g_DestinationComboBox.addItem(g_Destination);
		}
		
	}
	private void setTable(){
		G_Destination g_Destination = (G_Destination)g_DestinationComboBox.getSelectedItem();
		String dateString = dateTextField.getText().toString();
		ConfirmDao confirmDao = new ConfirmDao();
		List<HashMap<Integer, String>> confirmStatsList = confirmDao.getConfirmStatsList(g_Destination.getId(), dateString);
		DefaultTableModel dft = (DefaultTableModel) statsListTable.getModel();
		dft.setRowCount(0);
		for(HashMap<Integer, String> confirmStats : confirmStatsList){
			Set<Entry<Integer, String>> entrySet = confirmStats.entrySet();
			int confirmNum = 0 ;
			String dateString2 = "";
			for(Entry<Integer, String> entry : entrySet){
				confirmNum = entry.getKey();
				dateString2 = entry.getValue();
			}
			Vector v = new Vector();
			v.add(g_Destination.getName());
			v.add(confirmNum);
			v.add(g_Destination.getSelected_num()-confirmNum);
			v.add(g_Destination.getSelected_num());
			v.add(dateString2);
			dft.addRow(v);
		}
	}
	private void drawBar(int confirmNum,int studentNum, String date){
		setLanuage();
		DefaultCategoryDataset dataSet = new DefaultCategoryDataset();//����һ�����ݼ�
		dataSet.addValue(confirmNum, date, "��ȷ������");//��������
		dataSet.addValue(studentNum-confirmNum, date, "δȷ������");
		dataSet.addValue(studentNum, date, "������");
		//����һ��chart���󣬰����ݼ��Ž�ȥ
		JFreeChart chart = ChartFactory.createBarChart3D("��ҵ��ȷ��ͳ�����", "", "����", dataSet, PlotOrientation.VERTICAL, true, false, false);
		//����һ��ͼ��panel
		chartPanel= new ChartPanel(chart);
		//��ͼ��panel���ӵ�Ҫ��ʾ��panel��
		chartPanel.setPreferredSize(new Dimension(450,220));
		statsListPanel.add(chartPanel,BorderLayout.CENTER);
		statsListPanel.setLayout(new FlowLayout());
		statsListPanel.updateUI();
		statsListPanel.repaint();
	}
	private void clearPanel(){
		statsListPanel.removeAll();
		statsListPanel.updateUI();
		statsListPanel.repaint();
	}
	private void setLanuage(){
		//����������ʽ  
		   StandardChartTheme standardChartTheme=new StandardChartTheme("CN");  
		   //���ñ�������  
		   standardChartTheme.setExtraLargeFont(new Font("����",Font.BOLD,20));  
		   //����ͼ��������  
		   standardChartTheme.setRegularFont(new Font("����",Font.PLAIN,15));  
		   //�������������  
		   standardChartTheme.setLargeFont(new Font("����",Font.PLAIN,15));  
		   //Ӧ��������ʽ  
		   ChartFactory.setChartTheme(standardChartTheme);
	}
	private int getConfirmNum(G_Destination g_Destination,String dateString){
		ConfirmDao confirmDao = new ConfirmDao();
		List<HashMap<Integer, String>> confirmStatsList = confirmDao.getConfirmStatsList(g_Destination.getId(), dateString);
		int confirmNum = 0 ;
		for(HashMap<Integer, String> confirmStats : confirmStatsList){
			Set<Entry<Integer, String>> entrySet = confirmStats.entrySet();
			for(Entry<Integer, String> entry : entrySet){
				confirmNum = entry.getKey();
			}
		}
		return confirmNum;
	}
}
