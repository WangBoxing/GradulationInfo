package wbx.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import wbx.dao.ClassDao;
import wbx.model.StudentClass;
import wbx.util.StringUtil;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.Font;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JFrame;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextArea;

public class AddStudentClassIFrame extends JInternalFrame {

	private JPanel contentPane;
	private JTextField classNameTextField;
	private JTextField teacherNameTextField;
	private JTextArea classInfoTextArea;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddStudentClassIFrame frame = new AddStudentClassIFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddStudentClassIFrame() {
		setClosable(true);
		setIconifiable(true);
//		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 661, 308);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel(" \u73ED\u7EA7\u540D\u79F0\uFF1A");
		lblNewLabel.setIcon(new ImageIcon(AddStudentClassIFrame.class.getResource("/image/\u73ED\u7EA7\u7BA1\u7406.png")));
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		JLabel lblNewLabel_1 = new JLabel(" \u73ED\u4E3B\u4EFB\u59D3\u540D\uFF1A");
		lblNewLabel_1.setIcon(new ImageIcon(AddStudentClassIFrame.class.getResource("/image/\u5B66\u53F7\u7ED1\u5B9A.png")));
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		JLabel lblNewLabel_2 = new JLabel(" \u8BE6\u7EC6\u4FE1\u606F\uFF1A");
		lblNewLabel_2.setIcon(new ImageIcon(AddStudentClassIFrame.class.getResource("/image/img-daka.png")));
		lblNewLabel_2.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		classNameTextField = new JTextField();
		classNameTextField.setColumns(10);
		
		teacherNameTextField = new JTextField();
		teacherNameTextField.setColumns(10);
		
		JButton submitBtn = new JButton("\u63D0\u4EA4");
		submitBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				submitClass(act);
			}
		});
		submitBtn.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JButton resetBtn = new JButton("\u91CD\u7F6E");
		resetBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				resetValue(act);
			}
		});
		resetBtn.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		classInfoTextArea = new JTextArea();
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(95)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(Alignment.LEADING, gl_contentPane.createSequentialGroup()
									.addComponent(lblNewLabel_2)
									.addPreferredGap(ComponentPlacement.RELATED))
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
										.addComponent(submitBtn, GroupLayout.PREFERRED_SIZE, 73, GroupLayout.PREFERRED_SIZE)
										.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
									.addGap(16))))
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addGap(100)
							.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
							.addGap(11)))
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGap(18)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
								.addComponent(classNameTextField, GroupLayout.DEFAULT_SIZE, 153, Short.MAX_VALUE)
								.addComponent(teacherNameTextField)
								.addComponent(classInfoTextArea, GroupLayout.PREFERRED_SIZE, 295, GroupLayout.PREFERRED_SIZE))
							.addContainerGap(82, Short.MAX_VALUE))
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(resetBtn, GroupLayout.PREFERRED_SIZE, 73, GroupLayout.PREFERRED_SIZE)
							.addGap(141))))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(30)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(classNameTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel))
					.addGap(19)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(teacherNameTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_1))
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(classInfoTextArea, GroupLayout.PREFERRED_SIZE, 66, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_2))
					.addGap(27)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(resetBtn)
						.addComponent(submitBtn))
					.addContainerGap(46, Short.MAX_VALUE))
		);
		contentPane.setLayout(gl_contentPane);
	}

	protected void submitClass(ActionEvent act) {
		// TODO Auto-generated method stub
		String className = classNameTextField.getText().toString();
		String teacherName = teacherNameTextField.getText().toString();
		String classInfo = classInfoTextArea.getText().toString();
		if(StringUtil.isEmpty(className)) {
			JOptionPane.showMessageDialog(this, "�༶���Ʋ���Ϊ�գ�");
		}
		if(StringUtil.isEmpty(teacherName)) {
			JOptionPane.showMessageDialog(this, "��������������Ϊ�գ�");
		}
//		if(StringUtil.isEmpty(classInfo)) {
//			JOptionPane.showMessageDialog(this, "��ϸ��Ϣ����Ϊ�գ�");
//		}
		StudentClass sc = new StudentClass();
		sc.setCname(className);
		sc.setTname(teacherName);
		sc.setInfo(classInfo);
		ClassDao classDao = new ClassDao();
		if(classDao.addClass(sc)) {
			JOptionPane.showMessageDialog(this, "�༶���ӳɹ���");
		} else {
			JOptionPane.showMessageDialog(this, "�༶����ʧ�ܣ�");
		}
		classDao.closeDao();
		resetValue(act);
	}

	protected void resetValue(ActionEvent act) {
		// TODO Auto-generated method stub
		classNameTextField.setText("");
		teacherNameTextField.setText("");
		classInfoTextArea .setText("");
	}
}
