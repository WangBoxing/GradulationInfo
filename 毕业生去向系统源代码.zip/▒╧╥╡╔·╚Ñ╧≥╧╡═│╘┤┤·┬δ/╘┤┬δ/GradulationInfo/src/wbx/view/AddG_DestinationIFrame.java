package wbx.view;

import java.awt.EventQueue;

import javax.swing.JInternalFrame;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;

import java.awt.Font;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.JButton;

import wbx.dao.G_DestinationDao;
//import wbx.dao.TeacherDao;
import wbx.dao.UNGradulationDao;
import wbx.model.G_Destination;
//import wbx.model.Teacher;
import wbx.model.UNGradulation;
import wbx.util.StringUtil;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.List;

import javax.swing.JInternalFrame;

public class AddG_DestinationIFrame extends JInternalFrame {
	private JTextField g_destinationNameTextField;
	private JTextArea g_destinationInfoTextArea;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddG_DestinationIFrame frame = new AddG_DestinationIFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddG_DestinationIFrame() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u6DFB\u52A0\u8BFE\u7A0B");
		setBounds(100, 100, 570, 271);
		
		JLabel label = new JLabel(" \u6BD5\u4E1A\u53BB\u5411\uFF1A");
		label.setIcon(new ImageIcon(AddG_DestinationIFrame.class.getResource("/image/\u6BD5\u4E1A\u751F\u7BA1\u7406\u56FE\u6807.png")));
		label.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		g_destinationNameTextField = new JTextField();
		g_destinationNameTextField.setColumns(10);
		
		JLabel label_3 = new JLabel(" \u53BB\u5411\u4ECB\u7ECD\uFF1A");
		label_3.setIcon(new ImageIcon(AddG_DestinationIFrame.class.getResource("/image/\u601D\u8003.png")));
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		g_destinationInfoTextArea = new JTextArea();
		
		JButton addG_DestinationButton = new JButton("\u786E\u8BA4\u6DFB\u52A0");
		addG_DestinationButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				addG_DestinationAct(ae);
			}
		});
		addG_DestinationButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JButton resetButton = new JButton("\u91CD\u7F6E\u4FE1\u606F");
		resetButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				resetValue(ae);
			}
		});
		resetButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.TRAILING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(88)
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
							.addGap(47)
							.addComponent(addG_DestinationButton)
							.addGap(81)
							.addComponent(resetButton))
						.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
							.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
								.addComponent(label_3)
								.addComponent(label))
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
								.addComponent(g_destinationInfoTextArea)
								.addComponent(g_destinationNameTextField, GroupLayout.DEFAULT_SIZE, 263, Short.MAX_VALUE))))
					.addContainerGap(81, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(19)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(g_destinationNameTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(32)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_3)
						.addComponent(g_destinationInfoTextArea, GroupLayout.PREFERRED_SIZE, 68, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(addG_DestinationButton)
						.addComponent(resetButton))
					.addGap(24))
		);
		getContentPane().setLayout(groupLayout);
//		setTeacherCombox();
	}
	
	protected void resetValue(ActionEvent ae) {
		// TODO Auto-generated method stub
		g_destinationNameTextField.setText("");
		g_destinationInfoTextArea.setText("");
//		studentNumTextField.setText("");
//		teacherListComboBox.setSelectedIndex(0);
	}
	
	protected void addG_DestinationAct(ActionEvent ae) {
		// TODO Auto-generated method stub
		String couserName = g_destinationNameTextField.getText().toString();
		String g_destinationInfo = g_destinationInfoTextArea.getText().toString();
//		UNGradulation selectedTeacher = (UNGradulation)teacherListComboBox.getSelectedItem();
//		int studentMaxNum = 0;
//		try {
//			studentMaxNum = Integer.parseInt(studentNumTextField.getText());
//		} catch (Exception e) {
//			// TODO: handle exception
//			JOptionPane.showMessageDialog(this, "ѧ������ֻ����������!");
//			return;
//		}
		if(StringUtil.isEmpty(couserName)){
			JOptionPane.showMessageDialog(this, "������ȥ�����ƣ�");
			return;
		}
//		if(studentMaxNum <= 0){
//			JOptionPane.showMessageDialog(this, "ѧ������ֻ���������0������!");
//			return;
//		}
		G_Destination g_destination = new G_Destination();
		g_destination.setName(couserName);
//		g_destination.setMax_student_num(studentMaxNum);
		g_destination.setInfo(g_destinationInfo);
//		g_destination.setTeacher_id(selectedTeacher.getGsno());
		G_DestinationDao g_destinationDao = new G_DestinationDao();
		if(g_destinationDao.addG_Destination(g_destination)){
			JOptionPane.showMessageDialog(this, "���ӳɹ�!");
		}else{
			JOptionPane.showMessageDialog(this, "����ʧ��!");
		}
		g_destinationDao.closeDao();
		resetValue(ae);
	}
//	private void setTeacherCombox(){
//		UNGradulationDao teacherDao = new UNGradulationDao();
//		List<UNGradulation> teacherList = teacherDao.getTeacherList(new UNGradulation());
//		teacherDao.closeDao();
//		for (UNGradulation teacher : teacherList) {
//			teacherListComboBox.addItem(teacher);
//		}
//	}
}

