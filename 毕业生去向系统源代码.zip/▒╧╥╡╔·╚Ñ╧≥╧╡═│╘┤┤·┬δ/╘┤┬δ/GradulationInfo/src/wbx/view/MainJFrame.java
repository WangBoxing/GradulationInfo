package wbx.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import wbx.model.identity;

import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.ImageIcon;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JDesktopPane;
import java.awt.SystemColor;

public class MainJFrame extends JFrame {

	private JPanel contentPane;
	private JDesktopPane desktopPane;
	public static identity Identity;
	public static Object userObject;
	private JMenuItem addGMenuItem;
	private JMenuItem manageUNGMenuItem;
	private JMenuItem manageClassMenuItem;
	private JMenuItem viewSalaryMenuItem;
	private JMenuItem gradulationSubmitMenuItem;
	private JMenuItem addG_DestinationMenuItem;
	private JMenuItem addSalaryMenuItem;
	private JMenuItem manageSalaryMenuItem;
	private JMenuItem manageSubmitMenuItem;
	private JMenuItem selectDestinationMenuItem;

	/**
	 * Launch the application.
	 */
//	public static void main(String[] args) {
//		EventQueue.invokeLater(new Runnable() {
//			public void run() {
//				try {
//					MainJFrame frame = new MainJFrame();
//					frame.setVisible(true);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		});
//	}

	/**
	 * Create the frame.
	 */
	public MainJFrame(identity Identity,Object userObject) {
		this.Identity = Identity;
		this.userObject = userObject;
		setTitle("\u6BD5\u4E1A\u751F\u53BB\u5411\u7BA1\u7406\u7CFB\u7EDF\u4E3B\u754C\u9762");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 847, 621);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("\u7CFB\u7EDF\u8BBE\u7F6E");
		mnNewMenu.setForeground(Color.BLACK);
		mnNewMenu.setFont(new Font("Microsoft YaHei UI", Font.PLAIN, 12));
		mnNewMenu.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u7CFB\u7EDF\u8BBE\u7F6E\u56FE\u6807.png")));
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("\u4FEE\u6539\u5BC6\u7801");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				editPassword(act);
			}
		});
		mntmNewMenuItem.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u5BC6\u7801\u4FEE\u6539\u56FE\u6807.png")));
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("\u9000\u51FA\u767B\u5F55");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				if(JOptionPane.showConfirmDialog(MainJFrame.this, "ȷ���˳���") == JOptionPane.OK_OPTION) {
					System.exit(0);
				}
			}
		});
		mntmNewMenuItem_1.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u9000\u51FA\u7684\u56FE\u6807.png")));
		mnNewMenu.add(mntmNewMenuItem_1);
		
		JMenu mnNewMenu_1 = new JMenu("\u6BD5\u4E1A\u751F\u7BA1\u7406");
		mnNewMenu_1.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u6BD5\u4E1A\u751F\u7BA1\u7406\u56FE\u6807.png")));
		mnNewMenu_1.setForeground(Color.BLACK);
		menuBar.add(mnNewMenu_1);
		
		addGMenuItem = new JMenuItem("\u6BD5\u4E1A\u751F\u6DFB\u52A0");
		addGMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				AddG_StudentIFrame addG_StudentJFrame = new AddG_StudentIFrame();
				addG_StudentJFrame.setVisible(true);
				desktopPane.add(addG_StudentJFrame);
			}
		});
		addGMenuItem.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u6DFB\u52A0\u56FE\u6807.png")));
		mnNewMenu_1.add(addGMenuItem);
		
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("\u6BD5\u4E1A\u751F\u5217\u8868");
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageG_studentIFrame g_studentManagerJFrame = new ManageG_studentIFrame();
				g_studentManagerJFrame.setVisible(true);
				desktopPane.add(g_studentManagerJFrame);
			}
		});
		mntmNewMenuItem_3.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u5217\u8868\u56FE\u6807.png")));
		mnNewMenu_1.add(mntmNewMenuItem_3);
		
		JMenu mnNewMenu_2 = new JMenu("\u975E\u6BD5\u4E1A\u751F\u7BA1\u7406");
		mnNewMenu_2.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u975E\u6BD5\u4E1A\u751F\u7BA1\u7406\u56FE\u6807.png")));
		mnNewMenu_2.setForeground(Color.BLACK);
		menuBar.add(mnNewMenu_2);
		
		manageUNGMenuItem = new JMenuItem("\u975E\u6BD5\u4E1A\u751F\u6DFB\u52A0");
		manageUNGMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddUNG_StudentIFrame addUNG_StudentJFrame = new AddUNG_StudentIFrame();
				addUNG_StudentJFrame.setVisible(true);
				desktopPane.add(addUNG_StudentJFrame);
			}
		});
		manageUNGMenuItem.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u6DFB\u52A0\u56FE\u6807.png")));
		mnNewMenu_2.add(manageUNGMenuItem);
		
		JMenuItem mntmNewMenuItem_5 = new JMenuItem("\u975E\u6BD5\u4E1A\u751F\u5217\u8868");
		mntmNewMenuItem_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageUNG_studentIFrame ung_studentManagerJFrame = new ManageUNG_studentIFrame();
				ung_studentManagerJFrame.setVisible(true);
				desktopPane.add(ung_studentManagerJFrame);
			}
		});
		mntmNewMenuItem_5.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u5217\u8868\u56FE\u6807.png")));
		mnNewMenu_2.add(mntmNewMenuItem_5);
		
		JMenu mnNewMenu_3 = new JMenu("\u73ED\u7EA7\u7BA1\u7406");
		mnNewMenu_3.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u73ED\u7EA7\u7BA1\u7406\u56FE\u6807.png")));
		mnNewMenu_3.setForeground(Color.BLACK);
		menuBar.add(mnNewMenu_3);
		
		manageClassMenuItem = new JMenuItem("\u73ED\u7EA7\u6DFB\u52A0");
		manageClassMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				addStudentClass(act);
			}
		});
		manageClassMenuItem.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u6DFB\u52A0\u56FE\u6807.png")));
		mnNewMenu_3.add(manageClassMenuItem);
		
		JMenuItem mntmNewMenuItem_7 = new JMenuItem("\u73ED\u7EA7\u7BA1\u7406");
		mntmNewMenuItem_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				ManageClassIFrame classManagerJFrame = new ManageClassIFrame();
				classManagerJFrame.setVisible(true);
				desktopPane.add(classManagerJFrame);
			}
		});
		mntmNewMenuItem_7.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u73ED\u7EA7\u7BA1\u7406.png")));
		mnNewMenu_3.add(mntmNewMenuItem_7);
		
		JMenu mnNewMenu_4 = new JMenu("\u6BD5\u4E1A\u53BB\u5411\u7BA1\u7406");
		mnNewMenu_4.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u6BD5\u4E1A\u53BB\u5411\u7BA1\u7406\u56FE\u6807.png")));
		mnNewMenu_4.setForeground(Color.BLACK);
		menuBar.add(mnNewMenu_4);
		
		addG_DestinationMenuItem = new JMenuItem("\u53BB\u5411\u6DFB\u52A0");
		addG_DestinationMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddG_DestinationIFrame addG_DestinationIFrame = new AddG_DestinationIFrame();
				addG_DestinationIFrame.setVisible(true);
				desktopPane.add(addG_DestinationIFrame);
			}
		});
		addG_DestinationMenuItem.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u6DFB\u52A0\u56FE\u6807.png")));
		mnNewMenu_4.add(addG_DestinationMenuItem);
		
		JMenuItem destinationListMenuItem = new JMenuItem("\u53BB\u5411\u5217\u8868");
		destinationListMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MassageG_DestinationIFrame g_DestinationMassageIFrame = new MassageG_DestinationIFrame();
				g_DestinationMassageIFrame.setVisible(true);
				desktopPane.add(g_DestinationMassageIFrame);
			}
		});
		destinationListMenuItem.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u5217\u8868\u56FE\u6807.png")));
		mnNewMenu_4.add(destinationListMenuItem);
		
		JMenu mnNewMenu_5 = new JMenu("\u9009\u62E9\u53BB\u5411\u7BA1\u7406");
		mnNewMenu_5.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u9009\u62E9\u5217\u8868\u56FE\u6807.png")));
		mnNewMenu_5.setForeground(Color.BLACK);
		menuBar.add(mnNewMenu_5);
		
		selectDestinationMenuItem = new JMenuItem("\u9009\u62E9\u53BB\u5411\u7BA1\u7406");
		selectDestinationMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageSelectedDestinationIFrame manageSelectedDestinationIFrame = new ManageSelectedDestinationIFrame();
				manageSelectedDestinationIFrame.setVisible(true);
				desktopPane.add(manageSelectedDestinationIFrame);
			}
		});
		selectDestinationMenuItem.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u9009\u62E9\u5217\u8868\u56FE\u6807.png")));
		mnNewMenu_5.add(selectDestinationMenuItem);
		
		JMenu mnNewMenu_6 = new JMenu("\u85AA\u8D44\u7BA1\u7406");
		mnNewMenu_6.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u85AA\u8D44\u7BA1\u7406\u56FE\u6807.png")));
		mnNewMenu_6.setForeground(Color.BLACK);
		menuBar.add(mnNewMenu_6);
		
		addSalaryMenuItem = new JMenuItem("\u85AA\u8D44\u5F55\u5165");
		addSalaryMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AddSalaryIFrame addSalaryIFrame = new AddSalaryIFrame();
				addSalaryIFrame.setVisible(true);
				desktopPane.add(addSalaryIFrame);
			}
		});
		addSalaryMenuItem.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u6DFB\u52A0\u56FE\u6807.png")));
		mnNewMenu_6.add(addSalaryMenuItem);
		
		viewSalaryMenuItem = new JMenuItem("\u4E2A\u4EBA\u85AA\u8D44\u67E5\u770B");
		viewSalaryMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ViewSalaryIFrame viewSalaryIFrame = new ViewSalaryIFrame();
				viewSalaryIFrame.setVisible(true);
				desktopPane.add(viewSalaryIFrame);
			}
		});
		viewSalaryMenuItem.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u67E5\u770B\u56FE\u6807.png")));
		mnNewMenu_6.add(viewSalaryMenuItem);
		
		manageSalaryMenuItem = new JMenuItem("\u85AA\u8D44\u7BA1\u7406");
		manageSalaryMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageSalaryIFrame manageSalaryIFrame = new ManageSalaryIFrame();
				manageSalaryIFrame.setVisible(true);
				desktopPane.add(manageSalaryIFrame);
			}
		});
		manageSalaryMenuItem.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u85AA\u8D44\u7BA1\u7406\u56FE\u6807.png")));
		mnNewMenu_6.add(manageSalaryMenuItem);
		
		JMenuItem statsSalaryMenuItem = new JMenuItem("\u85AA\u8D44\u7EDF\u8BA1");
		statsSalaryMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StatsSalaryIFrame statsSalaryIFrame = new StatsSalaryIFrame();
				statsSalaryIFrame.setVisible(true);
				desktopPane.add(statsSalaryIFrame);
			}
		});
		statsSalaryMenuItem.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u85AA\u8D44\u7EDF\u8BA1.png")));
		mnNewMenu_6.add(statsSalaryMenuItem);
		
		JMenu mnNewMenu_7 = new JMenu("\u63D0\u4EA4\u786E\u8BA4");
		mnNewMenu_7.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u786E\u8BA4\u63D0\u4EA4\u56FE\u6807.png")));
		mnNewMenu_7.setForeground(Color.BLACK);
		menuBar.add(mnNewMenu_7);
		
		gradulationSubmitMenuItem = new JMenuItem("\u5B66\u751F\u786E\u8BA4");
		gradulationSubmitMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ConfirmIFrame confirmIFrame = new ConfirmIFrame();
				confirmIFrame.setVisible(true);
				desktopPane.add(confirmIFrame);
			}
		});
		gradulationSubmitMenuItem.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u5B66\u751F\u786E\u8BA4\u56FE\u6807.png")));
		mnNewMenu_7.add(gradulationSubmitMenuItem);
		
		manageSubmitMenuItem = new JMenuItem("\u786E\u8BA4\u7BA1\u7406");
		manageSubmitMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ManageGStudentConfirmIFrame gStudentConfirmIFrame = new ManageGStudentConfirmIFrame();
				gStudentConfirmIFrame.setVisible(true);
				desktopPane.add(gStudentConfirmIFrame);
			}
		});
		manageSubmitMenuItem.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u786E\u8BA4\u7BA1\u7406\u56FE\u6807.png")));
		mnNewMenu_7.add(manageSubmitMenuItem);
		
		JMenuItem statsSubmitMenuItem = new JMenuItem("\u786E\u8BA4\u7EDF\u8BA1");
		statsSubmitMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StatesConfirmIFrame statesConfirmIFrame = new StatesConfirmIFrame();
				statesConfirmIFrame.setVisible(true);
				desktopPane.add(statesConfirmIFrame);
			}
		});
		statsSubmitMenuItem.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u7EDF\u8BA1.png")));
		mnNewMenu_7.add(statsSubmitMenuItem);
		
		JMenu mnNewMenu_8 = new JMenu("\u5E2E\u52A9");
		mnNewMenu_8.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u601D\u8003.png")));
		mnNewMenu_8.setForeground(Color.BLACK);
		menuBar.add(mnNewMenu_8);
		
		JMenuItem mntmNewMenuItem_18 = new JMenuItem("\u5173\u4E8E\u6211\u4EEC");
		mntmNewMenuItem_18.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				aboutUs(act);
			}
		});
		mntmNewMenuItem_18.setIcon(new ImageIcon(MainJFrame.class.getResource("/image/\u5173\u4E8E\u6211\u4EEC\u56FE\u6807.png")));
		mnNewMenu_8.add(mntmNewMenuItem_18);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		desktopPane = new JDesktopPane();
		desktopPane.setBackground(SystemColor.control);
		contentPane.add(desktopPane, BorderLayout.CENTER);
		setLocationRelativeTo(null);
		setAuthority();
	}

	protected void addStudentClass(ActionEvent act) {
		// TODO Auto-generated method stub
		AddStudentClassIFrame sca = new AddStudentClassIFrame();
		sca.setVisible(true);
		desktopPane.add(sca);
	}

	protected void editPassword(ActionEvent act) {
		// TODO Auto-generated method stub
		EditPasswordIFrame editPasswordJFrame = new EditPasswordIFrame();
		editPasswordJFrame.setVisible(true);
		desktopPane.add(editPasswordJFrame);
	}

	protected void aboutUs(ActionEvent act) {
		// TODO Auto-generated method stub
		String info = "20195628������ \n";
		info += "20195629����� \n";
		info += "���ݿ���衶��ҵ��ȥ�����ϵͳ��";
		String[] btn = {"ȥ����","���뿴��"};
//		JOptionPane.showMessageDialog(this, info);
		int result = JOptionPane.showOptionDialog(this, "�������ǣ�", "��������", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.DEFAULT_OPTION, new ImageIcon(LoginJFrame.class.getResource("/image/logo.png")), btn, null);
		while(result == 0) {
			JOptionPane.showMessageDialog(this, info);
			result = JOptionPane.showOptionDialog(this, "�������ǣ�", "��������", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.DEFAULT_OPTION, new ImageIcon(LoginJFrame.class.getResource("/image/logo.png")), btn, null);
		}
		if(result != 0) {
			JOptionPane.showMessageDialog(this, "���뿴Ҳ�ÿ�~ \n" + info);
		}
	}
	
	private void setAuthority() {
		if("��ҵ��".equals(Identity.getName())) {
			addGMenuItem.setEnabled(false);
			manageUNGMenuItem.setEnabled(false);
			manageClassMenuItem.setEnabled(false);
			addG_DestinationMenuItem.setEnabled(false);
			addSalaryMenuItem.setEnabled(false);
			manageSalaryMenuItem.setEnabled(false);
			manageSubmitMenuItem.setEnabled(false);
		}
		if("�Ǳ�ҵ��".equals(Identity.getName())) {
			addGMenuItem.setEnabled(false);
			manageUNGMenuItem.setEnabled(false);
			manageClassMenuItem.setEnabled(false);
			addG_DestinationMenuItem.setEnabled(false);
			addSalaryMenuItem.setEnabled(false);
			manageSalaryMenuItem.setEnabled(false);
			manageSubmitMenuItem.setEnabled(false);
			gradulationSubmitMenuItem.setEnabled(false);
			selectDestinationMenuItem.setEnabled(false);
			viewSalaryMenuItem.setEnabled(false);
		}
		if("����Ա".equals(Identity.getName())) {
			viewSalaryMenuItem.setEnabled(false);
			gradulationSubmitMenuItem.setEnabled(false);
		}
	}

}
