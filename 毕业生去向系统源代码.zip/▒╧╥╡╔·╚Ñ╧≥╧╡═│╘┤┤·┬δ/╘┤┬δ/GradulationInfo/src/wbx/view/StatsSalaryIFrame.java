package wbx.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Map;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import wbx.dao.G_DestinationDao;
import wbx.dao.SalaryDao;
import wbx.model.G_Destination;
import wbx.model.UNGradulation;
import javax.swing.border.EtchedBorder;
import java.awt.Color;

public class StatsSalaryIFrame extends JInternalFrame {
	private JTextField maxSalaryTextField;
	private JTextField minSalaryTextField;
	private JTextField middSalaryTextField;
	private JTextField studentNumTextField;
	private JComboBox g_DestinationComboBox;
	private JPanel viewPanel;
	private List<G_Destination>g_DestinationList;
	private ChartPanel chartPanel ;
	private JPanel defaultPanel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StatsSalaryIFrame frame = new StatsSalaryIFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public StatsSalaryIFrame() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u6210\u7EE9\u7EDF\u8BA1\u754C\u9762");
		setBounds(100, 100, 657, 472);
		
		JLabel label = new JLabel(" \u53BB\u5411\uFF1A");
		label.setIcon(new ImageIcon(StatsSalaryIFrame.class.getResource("/image/\u6BD5\u4E1A\u53BB\u5411\u7BA1\u7406\u56FE\u6807.png")));
		label.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		g_DestinationComboBox = new JComboBox();
		
		JButton searchButton = new JButton("\u67E5\u8BE2");
		searchButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				searchStatsAct(ae);
			}
		});
		searchButton.setIcon(new ImageIcon(StatsSalaryIFrame.class.getResource("/image/\u6570\u636E\u67E5\u8BE2,\u6570\u636E\u5E93\u67E5\u8BE2.png")));
		searchButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		viewPanel = new JPanel();
		viewPanel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "\u85AA\u8D44\u7EDF\u8BA1\u4FE1\u606F", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "\u5207\u6362\u663E\u793A\u65B9\u5F0F", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.TRAILING)
						.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
							.addGap(113)
							.addComponent(label)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(g_DestinationComboBox, GroupLayout.PREFERRED_SIZE, 173, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 90, Short.MAX_VALUE)
							.addComponent(searchButton)
							.addGap(66))
						.addGroup(Alignment.LEADING, groupLayout.createSequentialGroup()
							.addGap(46)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING, false)
								.addComponent(panel_1, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(viewPanel, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 554, Short.MAX_VALUE))))
					.addGap(153))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(28)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(label)
						.addComponent(g_DestinationComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(searchButton))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(viewPanel, GroupLayout.PREFERRED_SIZE, 258, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(panel_1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(27, Short.MAX_VALUE))
		);
		
		JButton defaultViewButton = new JButton("\u9ED8\u8BA4\u663E\u793A");
		defaultViewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				defaultViewAct(ae);
			}
		});
		defaultViewButton.setIcon(new ImageIcon(StatsSalaryIFrame.class.getResource("/image/\u5217\u8868 (1).png")));
		defaultViewButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JButton barViewButton = new JButton("\u67F1\u72B6\u56FE\u663E\u793A");
		barViewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				barViewAct(ae);
			}
		});
		barViewButton.setIcon(new ImageIcon(StatsSalaryIFrame.class.getResource("/image/\u65E5\u671F\u7EDF\u8BA1.png")));
		barViewButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JButton pieViewButton = new JButton("\u997C\u72B6\u56FE\u663E\u793A");
		pieViewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				peiViewAct(ae);
			}
		});
		pieViewButton.setIcon(new ImageIcon(StatsSalaryIFrame.class.getResource("/image/\u997C\u72B6\u56FE (1).png")));
		pieViewButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		GroupLayout gl_panel_1 = new GroupLayout(panel_1);
		gl_panel_1.setHorizontalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_panel_1.createSequentialGroup()
					.addGap(39)
					.addComponent(defaultViewButton)
					.addPreferredGap(ComponentPlacement.RELATED, 53, Short.MAX_VALUE)
					.addComponent(barViewButton)
					.addGap(50)
					.addComponent(pieViewButton)
					.addGap(37))
		);
		gl_panel_1.setVerticalGroup(
			gl_panel_1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel_1.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel_1.createParallelGroup(Alignment.BASELINE)
						.addComponent(defaultViewButton)
						.addComponent(barViewButton)
						.addComponent(pieViewButton))
					.addContainerGap(27, Short.MAX_VALUE))
		);
		panel_1.setLayout(gl_panel_1);
		
		defaultPanel = new JPanel();
		GroupLayout gl_viewPanel = new GroupLayout(viewPanel);
		gl_viewPanel.setHorizontalGroup(
			gl_viewPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_viewPanel.createSequentialGroup()
					.addGap(37)
					.addComponent(defaultPanel, GroupLayout.PREFERRED_SIZE, 470, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(56, Short.MAX_VALUE))
		);
		gl_viewPanel.setVerticalGroup(
			gl_viewPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_viewPanel.createSequentialGroup()
					.addContainerGap()
					.addComponent(defaultPanel, GroupLayout.PREFERRED_SIZE, 207, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(132, Short.MAX_VALUE))
		);
		
		JLabel label_1 = new JLabel(" \u6700\u9AD8\u85AA\u8D44\uFF1A");
		label_1.setIcon(new ImageIcon(StatsSalaryIFrame.class.getResource("/image/\u6700\u9AD8 (1).png")));
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		maxSalaryTextField = new JTextField();
		maxSalaryTextField.setHorizontalAlignment(SwingConstants.CENTER);
		maxSalaryTextField.setEditable(false);
		maxSalaryTextField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel(" \u6700\u4F4E\u85AA\u8D44\uFF1A");
		lblNewLabel.setIcon(new ImageIcon(StatsSalaryIFrame.class.getResource("/image/\u6700\u4F4E (1).png")));
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		minSalaryTextField = new JTextField();
		minSalaryTextField.setHorizontalAlignment(SwingConstants.CENTER);
		minSalaryTextField.setEditable(false);
		minSalaryTextField.setColumns(10);
		
		JLabel label_2 = new JLabel("\u5E73\u5747\u85AA\u8D44\uFF1A");
		label_2.setIcon(new ImageIcon(StatsSalaryIFrame.class.getResource("/image/\u5E73\u5747 (2).png")));
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		middSalaryTextField = new JTextField();
		middSalaryTextField.setHorizontalAlignment(SwingConstants.CENTER);
		middSalaryTextField.setEditable(false);
		middSalaryTextField.setColumns(10);
		
		JLabel label_3 = new JLabel("\u603B\u4EBA\u6570\uFF1A");
		label_3.setIcon(new ImageIcon(StatsSalaryIFrame.class.getResource("/image/\u90E8\u95E8\u603B\u6570 (1).png")));
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		studentNumTextField = new JTextField();
		studentNumTextField.setHorizontalAlignment(SwingConstants.CENTER);
		studentNumTextField.setEditable(false);
		studentNumTextField.setColumns(10);
		GroupLayout gl_defaultPanel = new GroupLayout(defaultPanel);
		gl_defaultPanel.setHorizontalGroup(
			gl_defaultPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_defaultPanel.createSequentialGroup()
					.addGap(57)
					.addGroup(gl_defaultPanel.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_defaultPanel.createSequentialGroup()
							.addComponent(label_3)
							.addGap(18)
							.addComponent(studentNumTextField, GroupLayout.DEFAULT_SIZE, 242, Short.MAX_VALUE))
						.addGroup(gl_defaultPanel.createSequentialGroup()
							.addComponent(label_2)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(middSalaryTextField, GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE))
						.addGroup(gl_defaultPanel.createSequentialGroup()
							.addGroup(gl_defaultPanel.createParallelGroup(Alignment.LEADING)
								.addComponent(label_1)
								.addComponent(lblNewLabel))
							.addPreferredGap(ComponentPlacement.RELATED)
							.addGroup(gl_defaultPanel.createParallelGroup(Alignment.LEADING)
								.addComponent(maxSalaryTextField, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
								.addComponent(minSalaryTextField, 240, 240, 240))))
					.addGap(140))
		);
		gl_defaultPanel.setVerticalGroup(
			gl_defaultPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_defaultPanel.createSequentialGroup()
					.addGap(25)
					.addGroup(gl_defaultPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_1)
						.addComponent(maxSalaryTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_defaultPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(minSalaryTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_defaultPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_2)
						.addComponent(middSalaryTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(18)
					.addGroup(gl_defaultPanel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_3)
						.addComponent(studentNumTextField, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addContainerGap(114, Short.MAX_VALUE))
		);
		defaultPanel.setLayout(gl_defaultPanel);
		viewPanel.setLayout(gl_viewPanel);
		getContentPane().setLayout(groupLayout);
		setG_DestinationCombox();
	}
	protected void peiViewAct(ActionEvent ae) {
		// TODO Auto-generated method stub
		G_Destination g_Destination = (G_Destination)g_DestinationComboBox.getSelectedItem();
		SalaryDao salaryDao = new SalaryDao();
		Map<String, String> statsInfo = salaryDao.getStatsInfo(g_Destination.getId());
		clearPanel();
		drawCircle(Integer.parseInt(statsInfo.get("max_salary")), Integer.parseInt(statsInfo.get("min_salary")), Double.valueOf(statsInfo.get("mid_salary")), g_Destination.getName());
	}

	protected void barViewAct(ActionEvent ae) {
		// TODO Auto-generated method stub
		G_Destination g_Destination = (G_Destination)g_DestinationComboBox.getSelectedItem();
		SalaryDao salaryDao = new SalaryDao();
		Map<String, String> statsInfo = salaryDao.getStatsInfo(g_Destination.getId());
		clearPanel();
		drawBar(Integer.parseInt(statsInfo.get("student_num")), Integer.parseInt(statsInfo.get("max_salary")), Integer.parseInt(statsInfo.get("min_salary")), Double.valueOf(statsInfo.get("mid_salary")), g_Destination.getName());
	}

	protected void defaultViewAct(ActionEvent ae) {
		// TODO Auto-generated method stub
		clearPanel();
		G_Destination g_Destination = (G_Destination)g_DestinationComboBox.getSelectedItem();
		SalaryDao salaryDao = new SalaryDao();
		Map<String, String> statsInfo = salaryDao.getStatsInfo(g_Destination.getId());
		resetText();
		if(statsInfo.size() > 0){
			setDefaultPanel(statsInfo.get("student_num"),statsInfo.get("max_salary"),statsInfo.get("min_salary"),statsInfo.get("mid_salary"));
		}
	}

	protected void searchStatsAct(ActionEvent ae) {
		// TODO Auto-generated method stub
		defaultViewAct(ae);
	}

	private void setG_DestinationCombox(){
		G_DestinationDao g_DestinationDao = new G_DestinationDao();
		g_DestinationList = g_DestinationDao.getG_DestinationList(new G_Destination());
		g_DestinationDao.closeDao();
		for (G_Destination g_Destination : g_DestinationList) {
			if("�Ǳ�ҵ��".equals(MainJFrame.Identity.getName())){
//				UNGradulation uNGradulation = (UNGradulation)MainJFrame.userObject;
//				if(g_Destination.getUNGradulation_id() == uNGradulation.getId()){
					g_DestinationComboBox.addItem(g_Destination);
//				}
				continue;
			}
			//ִ�е�����һ���ǳ�������Ա����
			g_DestinationComboBox.addItem(g_Destination);
		}
		
	}
	private void resetText(){
		maxSalaryTextField.setText("");
		minSalaryTextField.setText("");
		middSalaryTextField.setText("");
		studentNumTextField.setText("");
	}
	private void drawBar(int studentNum,int maxSalary, int minSalary,double midSalary,String g_DestinationName){
		setLanuage();
		DefaultCategoryDataset dataSet = new DefaultCategoryDataset();//����һ�����ݼ�
		//dataSet.addValue(studentNum, g_DestinationName, "ѧ������");//��������
		dataSet.addValue(maxSalary, g_DestinationName+"(ѧ������:"+studentNum+")", "���н��");
		dataSet.addValue(minSalary, g_DestinationName+"(ѧ������:"+studentNum+")", "���н��");
		dataSet.addValue(midSalary, g_DestinationName+"(ѧ������:"+studentNum+")", "ƽ��н��");
		//����һ��chart���󣬰����ݼ��Ž�ȥ
		JFreeChart chart = ChartFactory.createBarChart3D("ѧ��н��ͳ�����", "н�����", "н��(��н)", dataSet, PlotOrientation.VERTICAL, true, false, false);
		//����һ��ͼ��panel
		chartPanel= new ChartPanel(chart);
		//��ͼ��panel���ӵ�Ҫ��ʾ��panel��
		chartPanel.setPreferredSize(new Dimension(500,220));
		viewPanel.add(chartPanel,BorderLayout.CENTER);
		viewPanel.setLayout(new FlowLayout());
		viewPanel.updateUI();
		viewPanel.repaint();
	}
	protected void drawCircle(int maxSalary, int minSalary,double midSalary,String g_DestinationName) {
		// TODO Auto-generated method stub
		setLanuage();
		DefaultPieDataset dataSet = new DefaultPieDataset();//�������ݼ�
		dataSet.setValue("���н��",maxSalary);//��������
		dataSet.setValue("���н��",minSalary);
		dataSet.setValue("ƽ��н��",midSalary);
		JFreeChart chart = ChartFactory.createPieChart3D(g_DestinationName+"ѧ��н��ͳ�����", dataSet, true, true, false);
		chartPanel = new ChartPanel(chart);
		chartPanel.setPreferredSize(new Dimension(540,220));
		viewPanel.add(chartPanel,BorderLayout.CENTER);
		viewPanel.setLayout(new FlowLayout());
		viewPanel.updateUI();
		viewPanel.repaint();
	}
	private void setDefaultPanel(String studentNum,String maxSalary, String minSalary,String midSalary){
		maxSalaryTextField.setText(maxSalary);
		minSalaryTextField.setText(minSalary);
		middSalaryTextField.setText(midSalary);
		studentNumTextField.setText(studentNum);
		//viewPanel.add(maxSalaryTextField);
		//viewPanel.add(minSalaryTextField);
		//viewPanel.add(middSalaryTextField);
		//viewPanel.add(studentNumTextField);
		viewPanel.add(defaultPanel);
		viewPanel.updateUI();
		viewPanel.repaint();
	}
	private void clearPanel(){
		viewPanel.removeAll();
		viewPanel.updateUI();
		viewPanel.repaint();
	}
	private void setLanuage(){
		//����������ʽ  
		   StandardChartTheme standardChartTheme=new StandardChartTheme("CN");  
		   //���ñ�������  
		   standardChartTheme.setExtraLargeFont(new Font("����",Font.BOLD,20));  
		   //����ͼ��������  
		   standardChartTheme.setRegularFont(new Font("����",Font.PLAIN,15));  
		   //�������������  
		   standardChartTheme.setLargeFont(new Font("����",Font.PLAIN,15));  
		   //Ӧ��������ʽ  
		   ChartFactory.setChartTheme(standardChartTheme);
	}
}