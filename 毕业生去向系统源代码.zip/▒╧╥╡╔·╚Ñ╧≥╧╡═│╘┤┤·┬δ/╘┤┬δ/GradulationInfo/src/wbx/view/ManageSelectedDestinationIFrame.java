package wbx.view;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;

import wbx.dao.G_DestinationDao;
import wbx.dao.SelectedG_DestinationDao;
import wbx.dao.GradulationDao;
import wbx.model.G_Destination;
import wbx.model.SelectedG_Destination;
import wbx.model.StudentClass;
import wbx.model.Gradulation;
import javax.swing.border.EtchedBorder;
import java.awt.Color;


public class ManageSelectedDestinationIFrame extends JInternalFrame {
	private JTable selectedG_DestinationListTable;
	private JComboBox searchDestinationComboBox;
	private JComboBox searchGStudentComboBox;
	private JComboBox editSelectedStudentComboBox;
	private JComboBox editSelectedG_DestinationComboBox;
	private List<Gradulation> gradulationList = new ArrayList<Gradulation>();
	private List<G_Destination> g_DestinationList = new ArrayList<G_Destination>();
	private JPanel panel;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManageSelectedDestinationIFrame frame = new ManageSelectedDestinationIFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManageSelectedDestinationIFrame() {
		setClosable(true);
		setIconifiable(true);
		setTitle("\u9009\u62E9\u53BB\u5411\u7BA1\u7406");
		setBounds(100, 100, 669, 486);
		
		JLabel label = new JLabel("\u5B66\u751F\uFF1A");
		label.setIcon(new ImageIcon(ManageSelectedDestinationIFrame.class.getResource("/image/\u5B66\u751F\u56FE\u6807.png")));
		label.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		searchGStudentComboBox = new JComboBox();
		
		JLabel label_1 = new JLabel(" \u6BD5\u4E1A\u53BB\u5411\uFF1A");
		label_1.setIcon(new ImageIcon(ManageSelectedDestinationIFrame.class.getResource("/image/\u6BD5\u4E1A\u53BB\u5411\u7BA1\u7406\u56FE\u6807.png")));
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		searchDestinationComboBox = new JComboBox();
		searchDestinationComboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent ie) {
				studentChangeAct(ie);
			}
		});
		
		JButton confirmSelectedButton = new JButton("\u786E\u8BA4\u9009\u62E9");
		confirmSelectedButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				confirmSelectedG_Destination(ae);
			}
		});
		confirmSelectedButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JScrollPane scrollPane = new JScrollPane();
		
		panel = new JPanel();
		panel.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "\u4FEE\u6539\u53BB\u5411", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		GroupLayout groupLayout = new GroupLayout(getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(46)
							.addComponent(label)
							.addGap(2)
							.addComponent(searchGStudentComboBox, GroupLayout.PREFERRED_SIZE, 124, GroupLayout.PREFERRED_SIZE)
							.addGap(20)
							.addComponent(label_1)
							.addGap(12)
							.addComponent(searchDestinationComboBox, GroupLayout.PREFERRED_SIZE, 127, GroupLayout.PREFERRED_SIZE)
							.addGap(26)
							.addComponent(confirmSelectedButton))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(82)
							.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
								.addComponent(panel, GroupLayout.PREFERRED_SIZE, 500, GroupLayout.PREFERRED_SIZE)
								.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 493, GroupLayout.PREFERRED_SIZE))))
					.addContainerGap(36, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(36)
							.addComponent(label))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(34)
							.addComponent(searchGStudentComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(34)
							.addComponent(label_1))
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(33)
							.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
								.addComponent(searchDestinationComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(confirmSelectedButton))))
					.addGap(18)
					.addComponent(scrollPane, GroupLayout.PREFERRED_SIZE, 216, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(32, Short.MAX_VALUE))
		);
		
		selectedG_DestinationListTable = new JTable();
		selectedG_DestinationListTable.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent me) {
				selectedG_Destination(me);
			}
		});
		selectedG_DestinationListTable.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"\u6240\u9009\u53BB\u5411\u7F16\u53F7", "\u5B66\u751F\u59D3\u540D", "\u53BB\u5411"
			}
		) {
			boolean[] columnEditables = new boolean[] {
				false, false, false
			};
			public boolean isCellEditable(int row, int column) {
				return columnEditables[column];
			}
		});
		selectedG_DestinationListTable.getColumnModel().getColumn(0).setPreferredWidth(61);
		selectedG_DestinationListTable.getColumnModel().getColumn(2).setPreferredWidth(114);
		scrollPane.setViewportView(selectedG_DestinationListTable);
		
		JLabel label_2 = new JLabel("\u5B66\u751F\uFF1A");
		label_2.setIcon(new ImageIcon(ManageSelectedDestinationIFrame.class.getResource("/image/\u5B66\u751F\u56FE\u6807.png")));
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		editSelectedStudentComboBox = new JComboBox();
		
		JLabel label_3 = new JLabel(" \u53BB\u5411\uFF1A");
		label_3.setIcon(new ImageIcon(ManageSelectedDestinationIFrame.class.getResource("/image/\u6BD5\u4E1A\u53BB\u5411\u7BA1\u7406\u56FE\u6807.png")));
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 16));
		
		editSelectedG_DestinationComboBox = new JComboBox();
		
		JButton confirmEditButton = new JButton("\u786E\u8BA4\u4FEE\u6539");
		confirmEditButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				editSelectG_DestinationAct(ae);
			}
		});
		confirmEditButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		
		JButton btnNewButton = new JButton("\u53D6\u6D88\u9009\u62E9");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent act) {
				deleteSelectedDestination(act);
			}
		});
		btnNewButton.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		GroupLayout gl_panel = new GroupLayout(panel);
		gl_panel.setHorizontalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.TRAILING, false)
						.addGroup(gl_panel.createSequentialGroup()
							.addComponent(label_3)
							.addGap(18)
							.addComponent(editSelectedG_DestinationComboBox, 0, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addGroup(gl_panel.createSequentialGroup()
							.addGap(5)
							.addComponent(label_2)
							.addGap(18)
							.addComponent(editSelectedStudentComboBox, GroupLayout.PREFERRED_SIZE, 127, GroupLayout.PREFERRED_SIZE)))
					.addGap(121)
					.addGroup(gl_panel.createParallelGroup(Alignment.LEADING, false)
						.addComponent(confirmEditButton, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						.addComponent(btnNewButton, GroupLayout.DEFAULT_SIZE, 97, Short.MAX_VALUE))
					.addGap(42))
		);
		gl_panel.setVerticalGroup(
			gl_panel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_2)
						.addComponent(editSelectedStudentComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnNewButton))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panel.createParallelGroup(Alignment.BASELINE)
						.addComponent(label_3)
						.addComponent(editSelectedG_DestinationComboBox, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(confirmEditButton))
					.addContainerGap(25, Short.MAX_VALUE))
		);
		panel.setLayout(gl_panel);
		getContentPane().setLayout(groupLayout);
		setStudentCombox();
		setG_DestinationCombox();
		initTable();
		setAuthority();
	}

	protected void deleteSelectedDestination(ActionEvent act) {
		// TODO Auto-generated method stub
		int row = selectedG_DestinationListTable.getSelectedRow();
		if(row == -1){
			JOptionPane.showMessageDialog(this, "��ѡ��Ҫ�޸ĵ����ݣ�");
			return;
		}
		int selected_id = Integer.parseInt(selectedG_DestinationListTable.getValueAt(row, 0).toString());
		String courseName = selectedG_DestinationListTable.getValueAt(row, 2).toString();
		SelectedG_Destination sc = new SelectedG_Destination();
		sc.setId(selected_id);
		SelectedG_DestinationDao scDao = new SelectedG_DestinationDao();
		G_DestinationDao g_DestinationDao = new G_DestinationDao();
		if(scDao.delete(selected_id)){
			if(g_DestinationDao.updateSelectedNum(getG_DestinationIdByName(courseName), -1)){
				JOptionPane.showMessageDialog(this, "ȡ��ѡ��ɹ���");
			}else{
				JOptionPane.showMessageDialog(this, "ȡ��ѡ��ɹ�������ȥ����Ϣʧ�ܣ�");
			}
		}else{
			JOptionPane.showMessageDialog(this, "ȡ��ѡ��ʧ�ܣ�");
		}
		scDao.closeDao();
		g_DestinationDao.closeDao();
		initTable();
	}

	protected void editSelectG_DestinationAct(ActionEvent ae) {
		// TODO Auto-generated method stub
		int row = selectedG_DestinationListTable.getSelectedRow();
		if(row == -1){
			JOptionPane.showMessageDialog(this, "��ѡ��Ҫ�޸ĵ����ݣ�");
			return;
		}
		
		int selected_id = Integer.parseInt(selectedG_DestinationListTable.getValueAt(row, 0).toString());
		String studentName = selectedG_DestinationListTable.getValueAt(row, 1).toString();
		String g_DestinationName = selectedG_DestinationListTable.getValueAt(row, 2).toString();
		Gradulation student = (Gradulation) editSelectedStudentComboBox.getSelectedItem();
		G_Destination g_Destination = (G_Destination) editSelectedG_DestinationComboBox.getSelectedItem();
		if(studentName.equals(student.getGsname())&&g_DestinationName.equals(g_Destination.getName())){
			JOptionPane.showMessageDialog(this, "��δ�޸����ݣ�");
			return;
		}
		G_DestinationDao g_DestinationDao = new G_DestinationDao();
//		if(!g_DestinationDao.selectedEnable(g_Destination.getId())){
//			JOptionPane.showMessageDialog(this, "�ÿγ��Ѿ�ѡ����������ѡ!");
//			return;
//		}
		
		SelectedG_Destination sg = new SelectedG_Destination();
		sg.setId(selected_id);
		sg.setStudent_id(student.getGsno());
		sg.setDestination_id(g_Destination.getId());
		SelectedG_DestinationDao scDao = new SelectedG_DestinationDao();
		if(scDao.isSelected(sg)){
			JOptionPane.showMessageDialog(this, "�Ѿ�ѡ�������ˣ�������ѡ!");
			return;
		}
		if(scDao.updateSelectedG_Destination(sg)){
			if(g_DestinationDao.updateSelectedNum(sg.getDestination_id(),1)){
				if(g_DestinationDao.updateSelectedNum(getG_DestinationIdByName(g_DestinationName), -1)){
					JOptionPane.showMessageDialog(this, "�޸ĳɹ���!");
				}
			}else{
				JOptionPane.showMessageDialog(this, "�޸ĳɹ���ȥ����Ϣ����ʧ��!");
			}
		}
		g_DestinationDao.closeDao();
		scDao.closeDao();
		initTable();
	}

	protected void selectedG_Destination(MouseEvent me) {
		// TODO Auto-generated method stub
		int row = selectedG_DestinationListTable.getSelectedRow();
		String studentName = selectedG_DestinationListTable.getValueAt(row, 1).toString();
		String g_DestinationName = selectedG_DestinationListTable.getValueAt(row, 2).toString();
		for (int i = 0; i < editSelectedStudentComboBox.getItemCount();i++) {
			Gradulation student = (Gradulation) editSelectedStudentComboBox.getItemAt(i);
			if(studentName.equals(student.getGsname())){
				editSelectedStudentComboBox.setSelectedIndex(i);
				break;
			}
		}
		for (int i = 0; i < editSelectedG_DestinationComboBox.getItemCount();i++) {
			G_Destination g_Destination = (G_Destination) editSelectedG_DestinationComboBox.getItemAt(i);
			if(g_DestinationName.equals(g_Destination.getName())){
				editSelectedG_DestinationComboBox.setSelectedIndex(i);
				break;
			}
		}
	}

	protected void studentChangeAct(ItemEvent ie) {
		// TODO Auto-generated method stub
		if(ie.getStateChange() == ItemEvent.SELECTED){
			initTable();
		}
		//JOptionPane.showMessageDialog(this, ie.getStateChange());
	}

	protected void confirmSelectedG_Destination(ActionEvent ae) {
		// TODO Auto-generated method stub
		Gradulation sstudent = (Gradulation) searchGStudentComboBox.getSelectedItem();
		G_Destination sg_Destination = (G_Destination) searchDestinationComboBox.getSelectedItem();
		SelectedG_Destination sc = new SelectedG_Destination();
		sc.setStudent_id(sstudent.getGsno());
		sc.setDestination_id(sg_Destination.getId());
		G_DestinationDao g_DestinationDao = new G_DestinationDao();
//		if(!g_DestinationDao.selectedEnable(sg_Destination.getId())){
//			JOptionPane.showMessageDialog(this, "�ÿγ��Ѿ�ѡ����������ѡ!");
//			return;
//		}
		SelectedG_DestinationDao scDao = new SelectedG_DestinationDao();
		if(scDao.isSelected(sc)){
			JOptionPane.showMessageDialog(this, "�Ѿ�ѡ�������ˣ�������ѡ!");
			return;
		}
		if(scDao.addSelectedG_Destination(sc)){
			if(g_DestinationDao.updateSelectedNum(sc.getDestination_id(),1)){
				JOptionPane.showMessageDialog(this, "ѡ��ɹ���!");
			}else{
				JOptionPane.showMessageDialog(this, "ѡ��ɹ���ȥ����Ϣ����ʧ��!");
			}
		}else{
			JOptionPane.showMessageDialog(this, "ѡ��ʧ��!");
		}
		g_DestinationDao.closeDao();
		scDao.closeDao();
		initTable();
	}

	private void setStudentCombox(){
		GradulationDao gradulationDao = new GradulationDao();
		gradulationList = gradulationDao.getG_studentList(new Gradulation());
		gradulationDao.closeDao();
		for (Gradulation gradulation : gradulationList) {
			searchGStudentComboBox.addItem(gradulation);
			editSelectedStudentComboBox.addItem(gradulation);
		}
		if("��ҵ��".equals(MainJFrame.Identity.getName())){
			Gradulation user = (Gradulation) MainJFrame.userObject;
			for(int i = 0; i < searchGStudentComboBox.getItemCount();i++){
				Gradulation student = (Gradulation) searchGStudentComboBox.getItemAt(i);
				if(student.getGsno() == user.getGsno()){
					searchGStudentComboBox.setSelectedIndex(i);
					editSelectedStudentComboBox.setSelectedIndex(i);
					break;
				}
			}
		}
	}
	private void setG_DestinationCombox(){
		G_DestinationDao g_DestinationDao = new G_DestinationDao();
		g_DestinationList = g_DestinationDao.getG_DestinationList(new G_Destination());
		g_DestinationDao.closeDao();
		for (G_Destination g_Destination : g_DestinationList) {
			searchDestinationComboBox.addItem(g_Destination);
			editSelectedG_DestinationComboBox.addItem(g_Destination);
		}
	}
	private void getSelectedG_Destination(SelectedG_Destination selectedG_Destination){
		SelectedG_DestinationDao selectedG_DestinationDao = new SelectedG_DestinationDao();
		List<SelectedG_Destination> selectedG_DestinationList = selectedG_DestinationDao.getSelectedG_DestinationList(selectedG_Destination);
		DefaultTableModel dft = (DefaultTableModel) selectedG_DestinationListTable.getModel();
		dft.setRowCount(0);
		for (SelectedG_Destination sc : selectedG_DestinationList) {
			Vector v = new Vector();
			v.add(sc.getId());
			v.add(getStudentNameById(sc.getStudent_id()));
			v.add(getG_DestinationNameById(sc.getDestination_id()));
			dft.addRow(v);
		}
		selectedG_DestinationDao.closeDao();
	}
	private void initTable(){
		G_Destination destination = (G_Destination) searchDestinationComboBox.getSelectedItem();
		SelectedG_Destination sc = new SelectedG_Destination();
		sc.setDestination_id(destination.getId());
		getSelectedG_Destination(sc);
		
	}
	private String getStudentNameById(int id){
		for (int i = 0; i < gradulationList.size(); i++) {
			if(gradulationList.get(i).getGsno() == id)return gradulationList.get(i).getGsname();
		}
		return "";
	}
	private String getG_DestinationNameById(int id){
		for (int i = 0; i < g_DestinationList.size(); i++) {
			if(id == g_DestinationList.get(i).getId())return g_DestinationList.get(i).getName();
		}
		return "";
	}
	private int getG_DestinationIdByName(String name){
		for (int i = 0; i < g_DestinationList.size(); i++) {
			if(name.equals(g_DestinationList.get(i).getName()))return g_DestinationList.get(i).getId();
		}
		return 0;
	}
	private void setAuthority(){
		if("��ҵ��".equals(MainJFrame.Identity.getName())){
			searchGStudentComboBox.setEnabled(false);
			editSelectedStudentComboBox.setEnabled(false);
			panel.setVisible(false);;
		}
	}
}




