/*
Navicat MySQL Data Transfer

Source Server         : mysql
Source Server Version : 80028
Source Host           : localhost:3306
Source Database       : db_gradulation

Target Server Type    : MYSQL
Target Server Version : 80028
File Encoding         : 65001

Date: 2022-04-18 21:23:44
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `g_admin`
-- ----------------------------
DROP TABLE IF EXISTS `g_admin`;
CREATE TABLE `g_admin` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `password` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `createDate` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of g_admin
-- ----------------------------
INSERT INTO `g_admin` VALUES ('1', '20195628', '1', '2022-04-10 22:01:39');
INSERT INTO `g_admin` VALUES ('2', '20195629', '2', '2022-04-11 22:13:30');

-- ----------------------------
-- Table structure for `g_class`
-- ----------------------------
DROP TABLE IF EXISTS `g_class`;
CREATE TABLE `g_class` (
  `Cno` int NOT NULL AUTO_INCREMENT,
  `Cname` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Tname` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Info` varchar(32) NOT NULL,
  PRIMARY KEY (`Cno`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of g_class
-- ----------------------------
INSERT INTO `g_class` VALUES ('1', '19级中加二班', '王*', '计算机科学与工程学院-19中加2班');
INSERT INTO `g_class` VALUES ('2', '19级中加三班', '李**', '计算机科学与工程学院-19中加3班');
INSERT INTO `g_class` VALUES ('6', '18级中加一班', '***', '计算机科学与工程学院-18中加1班');
INSERT INTO `g_class` VALUES ('7', '20级中加四班', '***', '计算机科学与工程学院-20中加4班');
INSERT INTO `g_class` VALUES ('8', '18级中加二班', '***', '计算机科学与工程学院-18中加2班');

-- ----------------------------
-- Table structure for `g_confirm`
-- ----------------------------
DROP TABLE IF EXISTS `g_confirm`;
CREATE TABLE `g_confirm` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `destination_id` int NOT NULL,
  `confirm_date` varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `student_confirm_foreign` (`student_id`) USING BTREE,
  KEY `destination_confirm_foreign` (`destination_id`) USING BTREE,
  CONSTRAINT `destination_confirm` FOREIGN KEY (`destination_id`) REFERENCES `g_destination` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `student_confirm` FOREIGN KEY (`student_id`) REFERENCES `g_gradulation` (`Gsno`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of g_confirm
-- ----------------------------
INSERT INTO `g_confirm` VALUES ('7', '1', '1', '2022-04-15');
INSERT INTO `g_confirm` VALUES ('8', '2', '3', '2022-04-15');
INSERT INTO `g_confirm` VALUES ('9', '9', '6', '2022-04-15');
INSERT INTO `g_confirm` VALUES ('10', '1', '1', '2022-04-16');

-- ----------------------------
-- Table structure for `g_destination`
-- ----------------------------
DROP TABLE IF EXISTS `g_destination`;
CREATE TABLE `g_destination` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `info` varchar(512) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `selected_num` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of g_destination
-- ----------------------------
INSERT INTO `g_destination` VALUES ('1', '考研', '考研一般指全国硕士研究生统一招生考试\n 全国硕士研究生统一招生考试\n简称“考研”或“统考”', '1');
INSERT INTO `g_destination` VALUES ('3', '考公', '公务员考试是公务员主管部门\n组织录用担任一级主任科员以下及\n其他相当职级层次的公务员的录用考试', '1');
INSERT INTO `g_destination` VALUES ('6', '出国留学', '指一个人去母国以外的国家接受各类教育\n时间可以为短期或长期（从几个星期到几年）', '1');

-- ----------------------------
-- Table structure for `g_gradulation`
-- ----------------------------
DROP TABLE IF EXISTS `g_gradulation`;
CREATE TABLE `g_gradulation` (
  `Gsno` int NOT NULL AUTO_INCREMENT,
  `Gsname` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Password` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Cno` int NOT NULL,
  `Sex` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`Gsno`),
  KEY `class_foreign` (`Cno`),
  CONSTRAINT `class_foreign` FOREIGN KEY (`Cno`) REFERENCES `g_class` (`Cno`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of g_gradulation
-- ----------------------------
INSERT INTO `g_gradulation` VALUES ('1', '王一', '111', '8', '女');
INSERT INTO `g_gradulation` VALUES ('2', '王二', '222', '6', '女');
INSERT INTO `g_gradulation` VALUES ('9', '王三', '333', '6', '男');
INSERT INTO `g_gradulation` VALUES ('10', '王四', '444', '6', '男');
INSERT INTO `g_gradulation` VALUES ('11', '王五', '555', '8', '男');

-- ----------------------------
-- Table structure for `g_salary`
-- ----------------------------
DROP TABLE IF EXISTS `g_salary`;
CREATE TABLE `g_salary` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int NOT NULL,
  `destination_id` int NOT NULL,
  `salary` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `student_salary_foreign` (`student_id`) USING BTREE,
  KEY `destination_id_salary_foreign` (`destination_id`) USING BTREE,
  CONSTRAINT `destination_id_salary_foreign` FOREIGN KEY (`destination_id`) REFERENCES `g_destination` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of g_salary
-- ----------------------------
INSERT INTO `g_salary` VALUES ('1', '1', '1', '0');

-- ----------------------------
-- Table structure for `g_selected_destination`
-- ----------------------------
DROP TABLE IF EXISTS `g_selected_destination`;
CREATE TABLE `g_selected_destination` (
  `id` int NOT NULL AUTO_INCREMENT,
  `student_id` int DEFAULT NULL,
  `destination_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_foreign` (`student_id`) USING BTREE,
  KEY `destination_foreign` (`destination_id`) USING BTREE,
  CONSTRAINT `destination_foreign` FOREIGN KEY (`destination_id`) REFERENCES `g_destination` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `student_foreign` FOREIGN KEY (`student_id`) REFERENCES `g_gradulation` (`Gsno`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of g_selected_destination
-- ----------------------------
INSERT INTO `g_selected_destination` VALUES ('1', '2', '3');
INSERT INTO `g_selected_destination` VALUES ('3', '9', '6');
INSERT INTO `g_selected_destination` VALUES ('5', '1', '1');

-- ----------------------------
-- Table structure for `ung_gradulation`
-- ----------------------------
DROP TABLE IF EXISTS `ung_gradulation`;
CREATE TABLE `ung_gradulation` (
  `Gsno` int NOT NULL AUTO_INCREMENT,
  `Gsname` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Password` varchar(32) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Cno` int NOT NULL,
  `Sex` varchar(8) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  PRIMARY KEY (`Gsno`),
  KEY `class_foreign` (`Cno`),
  CONSTRAINT `ung_gradulation_ibfk_1` FOREIGN KEY (`Cno`) REFERENCES `g_class` (`Cno`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3;

-- ----------------------------
-- Records of ung_gradulation
-- ----------------------------
INSERT INTO `ung_gradulation` VALUES ('1', '王小星', '111', '1', '女');
INSERT INTO `ung_gradulation` VALUES ('2', '聂小羊', '222', '1', '女');
INSERT INTO `ung_gradulation` VALUES ('3', '刘小花', '333', '2', '男');
INSERT INTO `ung_gradulation` VALUES ('9', '李小草', '444', '2', '男');
INSERT INTO `ung_gradulation` VALUES ('10', '吴小敏', '555', '7', '女');
INSERT INTO `ung_gradulation` VALUES ('11', '薛小可', '666', '7', '女');
